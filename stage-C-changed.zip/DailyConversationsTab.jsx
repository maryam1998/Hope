import React, { useState, useMemo, useEffect, useRef, useCallback, useContext, createContext } from "react";
import { ChevronDown, Check, RotateCcw, Loader2 } from "lucide-react";
import i18n from "./i18nconfig.js";

// تابعِ «ترجمه‌ی دوباره‌ی یک خط» که از app.jsx می‌آد (retranslateLine(text, langCode) → Promise<string>).
// با Context پاس می‌دیمش تا مجبور نباشیم از چند لایه کامپوننت prop رد کنیم.
const RetranslateContext = createContext(null);
const FA_OVERRIDE_PREFIX = "dcRetr:fa:";
function readFaOverride(text) {
  try { return localStorage.getItem(FA_OVERRIDE_PREFIX + text) || ""; } catch (e) { return ""; }
}
function writeFaOverride(text, value) {
  try { localStorage.setItem(FA_OVERRIDE_PREFIX + text, value); } catch (e) { /* ignore */ }
}
import {
  Hand, UserPlus, Users, Home, MessageCircleQuestion, Mail, MailCheck, DoorOpen, Phone,
  Bus, Fuel, CloudSun, UtensilsCrossed, ShoppingBag, BedDouble, Stethoscope,
  Compass, Palette, Briefcase, Clock, Heart, HelpCircle, Sparkles, Plane,
  HeartHandshake, UsersRound, Dumbbell, Laptop, PartyPopper, PawPrint, Languages,
  Siren, Landmark, GraduationCap, Wallet, BookOpen, Leaf, ChefHat, Clapperboard,
  Music, Building2, Mailbox, Sunrise, History, TreePine, Smile, Scroll, Store,
  FlaskConical, Globe, Cpu, MapPin, MapPinned, Soup, Swords, Fingerprint,
  HeartPulse, TrendingUp, Shirt, Scale, Newspaper, Building, MessageCircle,
} from "lucide-react";

/* =============================================================================
   نگاشت موضوع → (اسم فارسی، آیکون). کلید دقیقاً همون رشته‌ی topic توی
   DAILY_CONVERSATIONS.js هست، پس نیازی به تغییر دیتا نیست.
   ============================================================================= */
const TOPIC_META_LIST = [
  ["Greetings and Small Talk", "احوال‌پرسی و گفتگوی کوتاه", Hand],
  ["Introducing People", "معرفی افراد", UserPlus],
  ["Visiting an Old Friend", "دیدار دوست قدیمی", Home],
  ["Getting Acquainted (Personal Questions)", "آشنایی (سوالات شخصی)", MessageCircleQuestion],
  ["Invitations", "دعوت‌کردن", Mail],
  ["Accepting or Refusing an Invitation", "پذیرفتن یا رد کردن دعوت", MailCheck],
  ["Saying Goodbye", "خداحافظی", DoorOpen],
  ["Telephone Conversation", "مکالمه تلفنی", Phone],
  ["Transportation", "حمل‌ونقل", Bus],
  ["Gas Station and Auto Repair", "پمپ بنزین و تعمیر ماشین", Fuel],
  ["Weather and Seasons", "آب‌وهوا و فصل‌ها", CloudSun],
  ["At a Restaurant / Café", "رستوران و کافه", UtensilsCrossed],
  ["Shopping (Clothes and General)", "خرید (لباس و عمومی)", ShoppingBag],
  ["At a Hotel", "در هتل", BedDouble],
  ["Health and Doctor's Visit", "سلامتی و ویزیت دکتر", Stethoscope],
  ["Asking for Directions / Landmarks", "پرسیدن آدرس و نشانی", Compass],
  ["Plans and Free Time (Hobbies)", "برنامه‌ها و اوقات فراغت", Palette],
  ["Work and Workplace", "کار و محیط کار", Briefcase],
  ["Time and Appointments", "زمان و قرار ملاقات", Clock],
  ["Expressing Opinions and Feelings", "ابراز نظر و احساسات", Heart],
  ["Asking for Help and Clarification", "درخواست کمک و توضیح", HelpCircle],
  ["Politeness and Compliments", "ادب و تعارفات", Sparkles],
  ["Travel and Experiences", "سفر و تجربیات", Plane],
  ["Apologies and Forgiveness", "عذرخواهی و بخشش", HeartHandshake],
  ["Family and Cultural Questions", "خانواده و سوالات فرهنگی", UsersRound],
  ["Sports and Fitness", "ورزش و تناسب اندام", Dumbbell],
  ["Technology and Communication", "فناوری و ارتباطات", Laptop],
  ["Holidays and Celebrations", "تعطیلات و جشن‌ها", PartyPopper],
  ["Pets and Animals", "حیوانات خانگی", PawPrint],
  ["Learning a Language", "یادگیری زبان", Languages],
  ["Emergency Situations", "موقعیت‌های اضطراری", Siren],
  ["City Attractions and Sightseeing", "جاذبه‌های شهری و گردش", MapPinned],
  ["Schools and Education", "مدرسه و آموزش", GraduationCap],
  ["Money and Expenses", "پول و هزینه‌ها", Wallet],
  ["Books and Reading", "کتاب و مطالعه", BookOpen],
  ["Environment and Nature", "محیط‌زیست و طبیعت", Leaf],
  ["Cooking and Recipes", "آشپزی و دستور پخت", ChefHat],
  ["Movies and TV Series", "فیلم و سریال", Clapperboard],
  ["Music", "موسیقی", Music],
  ["Banking and Financial Services", "بانک و خدمات مالی", Building2],
  ["Post Office and Mail", "اداره پست", Mailbox],
  ["Neighbors and Community", "همسایه‌ها و جامعه", Users],
  ["Future Plans and Dreams", "برنامه‌های آینده و رویاها", Sunrise],
  ["Memories and Past Experiences", "خاطرات و تجربیات گذشته", History],
  // مکالمات موضوعی (THEMATIC_CONVERSATIONS) — همون توپیک‌ها به‌عنوان کارتِ
  // مستقل، کنار موضوعاتِ روزمره، تو همین گرید نشون داده می‌شن.
  // چهارمین عضوِ هر آرایه (enLabel) برچسبِ تمیزِ انگلیسیه که موقع
  // uiLang==="en" نشون داده می‌شه — جدا از کلیدِ اول (که عیناً همون رشته‌ی
  // مختلط فارسی/انگلیسیِ topic توی DAILY_CONVERSATIONS.js می‌مونه و فقط
  // برای lookup/شناسه استفاده می‌شه، هرگز رندر نمی‌شه).
  ["طبیعت (Nature)", "طبیعت", TreePine, "Nature"],
  ["احساسات (Emotions)", "احساسات", Smile, "Emotions"],
  ["مذهب و سیاست (Religion and Politics)", "مذهب و سیاست", Scroll, "Religion and Politics"],
  ["خرید (Retail)", "خرید", Store, "Retail"],
  ["علوم (Science)", "علوم", FlaskConical, "Science"],
  ["مسائل اجتماعی (Social Issues)", "مسائل اجتماعی", Globe, "Social Issues"],
  ["فناوری (Technology)", "فناوری", Cpu, "Technology"],
  ["سفر و گردشگری (Travel and Tourism)", "سفر و گردشگری", MapPin, "Travel and Tourism"],
  ["غذا و آشپزی (Food and Cooking)", "غذا و آشپزی", Soup, "Food and Cooking"],
  ["جنگ و درگیری (War and Conflict)", "جنگ و درگیری", Swords, "War and Conflict"],
  ["شغل (Work)", "شغل", Briefcase, "Work"],
  ["شخصیت (Personality)", "شخصیت", Fingerprint, "Personality"],
  ["بدن انسان (Body)", "بدن انسان", HeartPulse, "Body"],
  ["کسب و کار (Business)", "کسب و کار", TrendingUp, "Business"],
  ["لباس و مد (Clothes and Fashion)", "لباس و مد", Shirt, "Clothes and Fashion"],
  ["جرم و قانون (Crime and Law)", "جرم و قانون", Scale, "Crime and Law"],
  ["فرهنگ (Culture)", "فرهنگ", Landmark, "Culture"],
  ["آموزش و تحصیل (Education)", "آموزش و تحصیل", GraduationCap, "Education"],
  ["رسانه (The Media)", "رسانه", Newspaper, "The Media"],
  ["حیوانات (Animals)", "حیوانات", PawPrint, "Animals"],
  ["خانه (Home and Housing)", "خانه", Building, "Home and Housing"],
];
// نامِ نمایشیِ هر موضوع از locales/<lang>.json می‌آد (کلیدِ dialogs_topic_<slug>)؛
// slug از برچسبِ انگلیسیِ تمیز ساخته می‌شه. اگه ترجمه‌ای نبود، i18n به انگلیسی برمی‌گرده.
const topicLabelKey = (label) => "dialogs_topic_" + String(label).toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
const TOPIC_META = {};
TOPIC_META_LIST.forEach(([en, fa, icon, enLabel]) => (TOPIC_META[en] = { fa, icon, enLabel: enLabel || en, labelKey: topicLabelKey(enLabel || en) }));
function topicLabel(meta, uiLang) {
  if (!meta) return "";
  if (!meta.labelKey) return isRtlUi(uiLang) ? meta.fa : (meta.enLabel || meta.fa);
  return i18n.getFixedT(uiLang || "fa")(meta.labelKey, { defaultValue: isRtlUi(uiLang) ? meta.fa : (meta.enLabel || meta.en) });
}
// فارسی و عربی راست‌چین‌ان؛ بقیه چپ‌به‌راست.
const isRtlUi = (lang) => lang === "fa" || lang === "ar";

// رشته‌های این تب از locales/<lang>.json (کلیدهای dialogs_*) خونده می‌شن.
function convStrings(uiLang) {
  const tt = i18n.getFixedT(uiLang || "fa");
  return {
    comingSoon: tt("dialogs_coming_soon"),
    youHear: tt("dialogs_you_hear"),
    youSay: tt("dialogs_you_say"),
    noResults: tt("dialogs_no_results"),
    backToTopics: tt("dialogs_back_to_topics"),
    toggleRead: tt("dialogs_toggle_read"),
  };
}

// همون توکن‌های رنگ/فونتِ کل اپ (app.jsx) — چون این‌ها همه روی متغیرهای CSS
// سراسری (--c-ink و ...) سوارن که خودِ App روی یه div ریشه ست می‌کنه، همینجا
// دوباره تعریف‌شون کردن هیچ وابستگی جدیدی نمی‌سازه و باعث می‌شه این تب هم
// دقیقاً مثل بقیه‌ی تب‌ها با تعویض تم (اقیانوسی/جنگلی/شب...) عوض بشه.
const colors = {
  paper: "var(--c-paper)",
  paperDark: "var(--c-paperDark)",
  ink: "var(--c-ink)",
  inkSoft: "var(--c-inkSoft)",
  gold: "var(--c-gold)",
  goldSoft: "var(--c-goldSoft)",
  teal: "var(--c-teal)",
  rose: "var(--c-rose)",
  cardBorder: "var(--c-cardBorder)",
};
// طبق درخواست: متن اصلی (جمله‌ی انگلیسی) مشکی/سورمه‌ای پررنگ و بولد،
// و متنِ ترجمه‌ها سبزِ پررنگ و بولد — این دو تا رنگ ثابتن (نه وابسته به
// تم انتخابی) چون خودِ کاربر رنگ مشخص خواسته.
const mainTextColor = "#0B1220";
const translationColor = "#0F5C34";
// رنگِ ثابتِ «ماژیک هایلایتِ خواندن» — دقیقاً همون مقداری که تو app.jsx
// برای داستان‌ساز و لغات استفاده می‌شه (اینجا هم محلی تعریف شده، عیناً به
// همون دلیلی که colors/mainTextColor بالا محلی تعریف شدن) تا هایلایتِ
// جمله‌ی درحالِ‌خواندن، توی همه‌ی تب‌ها دقیقاً یک رنگ باشه.
const READ_MARKER_COLOR = "#FFD54F";
// گرادیانتِ طلاییِ «خوانده‌شده» — همون افکتِ .card.done توی
// language-app-home.html، اینجا هم برای هدرِ سناریوهای بازشونده استفاده
// می‌شه تا با بقیه‌ی جاهای اپ یکسان باشه.
const READ_DONE_GRADIENT = "linear-gradient(150deg, #F8F2DE 0%, #F1E6C6 100%)";
const READ_DONE_BORDER = "#E3D2A2";
const READ_DONE_SHADOW = "0 2px 8px -6px rgba(150,120,40,.15)";
// تیکِ «خوانده‌شده» همیشه سبزه (مستقل از تمِ رنگیِ فعال یا readDoneColor)
// تا با بقیه‌ی تب‌های اپ (لغات، داستان‌ها، یادداشت‌ها) دقیقاً یکدست بمونه.
const READ_DONE_CHECK_GRADIENT = "linear-gradient(135deg, #3F9B72, #276E4F)";
const fontFa = "var(--font-fa)";
const fontLatin = "var(--font-latin)";
// نسخه‌ی محلیِ نگاشتِ لوکالِ TTS — عیناً همون چیزی که app.jsx داره (برای
// ساختِ کلیدِ speechController: `${locale}::${text}`). این‌جا فقط برای
// تشخیصِ این‌که «همین الان کدوم زبانِ ترجمه داره خونده می‌شه» لازمه، پس
// یه کپیِ محلی (مثلِ colors/mainTextColor بالاتر) کافیه.
const TTS_LOCALE_MINI = {
  fa: "fa-IR",
  en: "en-US",
  de: "de-DE",
  es: "es-ES",
  fr: "fr-FR",
  ar: "ar-SA",
  tr: "tr-TR",
  zh: "zh-CN",
  ru: "ru-RU",
  it: "it-IT",
  ko: "ko-KR",
  ja: "ja-JP",
  hi: "hi-IN",
  ga: "ga-IE",
  uk: "uk-UA",
};

// پالتِ رنگِ پس‌زمینه‌ی دایره‌ی آیکون — همون چهار رنگِ ملایمِ طرحِ اصلی
// (language-app-home.html)، به‌ترتیب بین کارت‌ها می‌چرخه تا شبکه یکنواخت
// نباشه، دقیقاً مثل نسخه‌ی مرجع.
const TOPIC_BADGE_COLORS = ["#EAF4F1", "#FBF0DA", "#F3ECFB", "#FBE9E4"];

// یه رشته رو، فقط برای مصرفِ TTS/هایلایت (نه نمایشِ رویِ صفحه)، اگه با
// یکی از علامت‌های‌نگارشیِ پایانِ‌جمله (فارسی/عربی/لاتین/آسیای‌شرقی) تموم
// نشده باشه، با یه نقطه‌ی معمولی می‌بنده — تا splitSentencesRaw همیشه
// بتونه مرزِ این خط رو تشخیص بده.
function ensureSentenceEnd(s) {
  const trimmed = (s || "").trim();
  if (!trimmed) return trimmed;
  return /[.!?؟。！…]$/.test(trimmed) ? trimmed : trimmed + ".";
}

function TopicCard({ meta, index, hasData, onClick, uiLang, isRead, onToggleRead, readDoneColor, readDoneBg }) {
  const label = topicLabel(meta, uiLang);
  const badgeColor = TOPIC_BADGE_COLORS[(index || 0) % TOPIC_BADGE_COLORS.length];
  const Icon = meta.icon || MessageCircle;
  return (
    <div
      dir={isRtlUi(uiLang) ? "rtl" : "ltr"}
      onClick={onClick}
      style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 8,
        padding: "14px 8px 12px",
        borderRadius: 16,
        textAlign: "center",
        cursor: "pointer",
        border: `1px solid ${isRead ? READ_DONE_BORDER : colors.cardBorder}`,
        // کارتِ «خوانده‌شده» گرادیانتِ طلاییِ ملایم می‌گیره، دقیقاً مثل
        // .card.done توی طرحِ مرجع؛ کارتِ معمولی سفیدِ ساده.
        background: isRead ? READ_DONE_GRADIENT : "#fff",
        boxShadow: isRead ? READ_DONE_SHADOW : "none",
        opacity: hasData ? 1 : 0.55,
        minHeight: 96,
        transition: "transform .15s ease, box-shadow .15s ease",
      }}
    >
      {/* دایره‌ی خوانده‌شده — گوشه‌ی بالا سمتِ خلافِ جهتِ متن (مثلِ
          bookmark-ring مرجع)، خط‌چین وقتی خونده‌نشده، طلایی و توپر با تیکِ
          سفید وقتی خونده‌شده. */}
      <button
        onClick={(ev) => {
          ev.stopPropagation();
          onToggleRead && onToggleRead();
        }}
        aria-label={i18n.getFixedT(uiLang || "fa")("dialogs_toggle_read")}
        style={{
          position: "absolute",
          top: 8,
          [isRtlUi(uiLang) ? "right" : "left"]: 8,
          width: 20,
          height: 20,
          borderRadius: "50%",
          border: isRead ? `1.6px solid ${READ_DONE_BORDER}` : "1.6px dashed #C8BE95",
          background: isRead ? READ_DONE_CHECK_GRADIENT : "#fff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {isRead && <Check size={11} color="#fff" strokeWidth={3} />}
      </button>
      <span
        style={{
          width: 46,
          height: 46,
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          lineHeight: 1,
          background: isRead ? "rgba(255,255,255,.55)" : badgeColor,
        }}
      >
        <Icon size={21} strokeWidth={2} color={isRead ? "#2E7D6C" : colors.teal} />
      </span>
      <span style={{ fontFamily: isRtlUi(uiLang) ? fontFa : fontLatin, fontSize: 12.3, fontWeight: 600, color: colors.ink, lineHeight: 1.55 }}>
        {label}
      </span>
    </div>
  );
}

// ترجمه‌ی زنده‌ی یک خط به یک زبان مقصد. اگه زبان فارسیه و از قبل توی خودِ
// دیتا (it.fa) موجوده، همون رو مستقیم نشون می‌ده (بدون درخواست شبکه)؛
// برای بقیه‌ی زبان‌ها (هر چی که کاربر بالای صفحه اضافه کنه) با همون
// translateFree که به کل اپ وصله می‌گیره — و چون translateFree خودش کش
// IndexedDB داره، دفعه‌ی بعد همون ترجمه بدون اینترنت هم در دسترسه.
function LineTranslation({ text, langCode, variant, i, knownFa, aiSettings, translateFree, SpeakButton, ClickableSentence, nativeLang, nativeLabel, autoScrollActive, highlightColor, fullText, lineOffsets, isActiveLine, onResolved }) {
  const [value, setValue] = useState(langCode === "fa" ? readFaOverride(text) || knownFa || "" : "");
  const [loading, setLoading] = useState(langCode !== "fa" && !knownFa);
  const retranslateLine = useContext(RetranslateContext);
  const [refreshing, setRefreshing] = useState(false);

  // دکمه‌ی رفرش: اگه ترجمه‌ی این خط غلطه، مستقیم از AI/شبکه دوباره می‌گیره (نه از کش)
  const onRefresh = async (e) => {
    if (e && e.stopPropagation) e.stopPropagation();
    if (!retranslateLine || refreshing) return;
    setRefreshing(true);
    try {
      const res = await retranslateLine(text, langCode);
      if (res && String(res).trim()) {
        setValue(res);
        if (langCode === "fa") writeFaOverride(text, res);
      }
    } catch (err) {
      // شکست خورد؛ ترجمه‌ی قبلی می‌مونه
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (langCode === "fa") {
      setValue(readFaOverride(text) || knownFa || "");
      setLoading(false);
      return;
    }
    if (!translateFree) return;
    let cancelled = false;
    setLoading(true);
    translateFree(text, langCode, "en", aiSettings)
      .then((res) => {
        if (!cancelled) setValue(res || "");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [text, langCode, knownFa]);

  // به محضِ این‌که ترجمه‌ی این خط آماده شد، به بالا (DailyConversationsTab)
  // خبر می‌دیم — والد از روی مقدارِ همه‌ی خط‌ها، «متنِ کاملِ ترجمه‌ها»یِ
  // همین زبان رو می‌سازه؛ دقیقاً همون الگویی که برای متنِ اصلیِ انگلیسی
  // (fullText/lineOffsets در سطحِ تب) استفاده شده، این‌جا هم برای هر زبانِ
  // ترجمه تکرار می‌شه.
  useEffect(() => {
    if (!loading && value && onResolved && variant != null && i != null) {
      onResolved(langCode, variant, i, value);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, value, langCode, variant, i]);

  // isActiveLine از والد میاد (بر اساسِ آفستِ واقعیِ پخشِ speechController
  // داخلِ fullTextِ همین زبان) — دقیقاً همون مکانیزمی که خطِ اصلیِ انگلیسی
  // استفاده می‌کنه، نه یه مقایسه‌ی سادهٔ متنیِ محلی مثلِ قبل (که با پخشِ
  // پیوسته/ادامه‌دار کار نمی‌کرد).
  const rowRef = useRef(null);
  useEffect(() => {
    if (!autoScrollActive || !isActiveLine) return;
    if (rowRef.current && rowRef.current.scrollIntoView) {
      rowRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [autoScrollActive, isActiveLine]);

  if (!value && !loading) return null;

  const highlightStyle = {
    backgroundColor: isActiveLine ? (highlightColor || READ_MARKER_COLOR) : "transparent",
    borderRadius: 5,
    padding: isActiveLine ? "2px 4px" : "2px 0",
    WebkitBoxDecorationBreak: "clone",
    boxDecorationBreak: "clone",
    transition: "background-color 0.35s ease",
  };

  // آفستِ همین خطِ ترجمه داخلِ fullTextِ کاملِ همین زبان — با این، زدنِ
  // 🔊ِ این خط، دقیقاً از همینجا وارد پخشِ پیوسته‌ی همه‌ی ترجمه‌های همین
  // زبان می‌شه (نه فقط همین یه خط)، و خودش تا آخر ادامه پیدا می‌کنه؛
  // درست مثلِ رفتارِ بلندگوی متنِ اصلیِ انگلیسی.
  const myOffset = lineOffsets && lineOffsets.find((o) => o.variant === variant && o.i === i);

  return (
    // طبق درخواست: این ردیف هم مثل متنِ اصلی چپ‌به‌راست نوشته می‌شه، ولی
    // بلندگو طبق قانونِ کلیِ خودِ SpeakButton («همیشه سمت راستِ ردیف») باید
    // edge="end" بگیره — وگرنه چون ردیف رو ltr کردیم ولی این پراپ رو ندادیم،
    // بلندگو با فرضِ پیش‌فرضِ راست‌چین می‌رفت سمت چپ (دقیقاً برعکسِ خواسته).
    <div ref={rowRef} style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 4, direction: "ltr" }}>
      {value && SpeakButton && (
        <SpeakButton
          text={value}
          code={langCode}
          color={translationColor}
          edge="end"
          fullText={fullText}
          startOffset={myOffset ? myOffset.start : undefined}
          neuralId={`conv:${langCode}::${text}`}
          neuralLabel={i18n.t("dialogs_neural_translation")}
        />
      )}
      <span
        style={{
          fontFamily: fontFa,
          fontSize: 9,
          fontWeight: 700,
          color: colors.gold,
          border: `1px solid ${colors.goldSoft}`,
          borderRadius: 6,
          padding: "0px 5px",
          flexShrink: 0,
        }}
      >
        {langCode.toUpperCase()}
      </span>
      {loading ? (
        <span style={{ fontSize: 12, color: colors.inkSoft, flex: 1 }}>...</span>
      ) : ClickableSentence ? (
        <span style={{ flex: 1, ...highlightStyle }}>
          <ClickableSentence
            text={value}
            langCode={langCode}
            nativeLang={nativeLang}
            nativeLabel={nativeLabel}
            aiSettings={aiSettings}
            color={translationColor}
            fontFamily={fontFa}
            fontWeight={900}
            fontSize={13}
          />
        </span>
      ) : (
        <span style={{ fontSize: 13, color: translationColor, fontWeight: 900, fontFamily: fontFa, flex: 1, ...highlightStyle }}>{value}</span>
      )}
      {!loading && value && retranslateLine && (
        <button
          onClick={onRefresh}
          disabled={refreshing}
          title={i18n.t("dialogs_retranslate_title")}
          aria-label={i18n.t("dialogs_retranslate_aria")}
          style={{ background: "none", border: "none", padding: 4, flexShrink: 0, cursor: refreshing ? "default" : "pointer", display: "flex", alignItems: "center" }}
        >
          {refreshing ? (
            <Loader2 size={12} className="spin" color={translationColor} />
          ) : (
            <RotateCcw size={12} color={translationColor} style={{ opacity: 0.6 }} />
          )}
        </button>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 🐛 باگِ اصلی («زبانِ مادری روی فارسی قفل شده»): ردیف‌های ترجمه‌ی این تب
// (چه توی خودِ ConversationBox، چه توی سیستمِ «خواندنِ پیوسته»ی پایین‌تر)
// همیشه از رویِ `targetLangs` (زبان‌های *مقصد*ی که کاربر داره یاد می‌گیره)
// ساخته می‌شدن — نه `nativeLang` (زبانِ مادریِ واقعیِ کاربر که جدا از
// targetLangs پاس داده می‌شه). وقتی targetLangs خالی بود، مستقیم به‌جای
// nativeLang از رشته‌ی هاردکدشده‌ی "fa" استفاده می‌شد؛ و حتی وقتی targetLangs
// چیزی داشت، اگه زبانِ مادریِ کاربر (مثلاً آلمانی) جزوِ همون لیستِ یادگیری
// نبود، هیچ ردیفی برای زبانِ مادری‌ش اصلاً نشون داده نمی‌شد. نتیجه: عملاً
// انتخابِ زبانِ مادری هیچ‌وقت این تب رو تحتِ‌تأثیر قرار نمی‌داد و همیشه (یا
// فارسی، یا فقط زبان‌های یادگیری) نشون داده می‌شد. راه‌حل: دقیقاً همون
// الگویی که برای WordList/PhraseList (تبِ لغات/عبارات) پیاده شد — زبانِ
// مادری همیشه اول لیست میاد (اگه از قبل جزوِ targetLangs نبود)، بعد زبان‌های
// یادگیری.
function buildDisplayLangCodes(nativeLang, targetLangs) {
  const targetCodes = (targetLangs && targetLangs.length ? targetLangs.map((l) => l.code) : []).filter((c) => c !== "en");
  if (nativeLang && nativeLang !== "en" && !targetCodes.includes(nativeLang)) {
    return [nativeLang, ...targetCodes];
  }
  if (targetCodes.length) return targetCodes;
  return nativeLang && nativeLang !== "en" ? [nativeLang] : ["fa"];
}

function ConversationBox({ items, variant, label, nativeLang, nativeLabel, aiSettings, ClickableSentence, SpeakButton, targetLangs, translateFree, activeLine, registerLineRef, highlightColor, fullText, lineOffsets, autoScrollActive, translationTextInfo, activeTranslationLine, onResolveTranslation }) {
  const isHear = variant === "hear";
  if (items.length === 0) return null;
  const accent = isHear ? colors.teal : colors.gold;
  const langCodes = buildDisplayLangCodes(nativeLang, targetLangs);
  return (
    <div>
      {/* eyebrow: بج دایره‌ای رنگی (تیل برای می‌شنوی، طلایی برای می‌گی) + برچسب —
          همون زبانِ بج‌های سطح/زبان که توی تب لغات هست، نه یه استایل جدا */}
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: isHear ? 10 : 14, marginBottom: 6 }}>
        <span
          style={{
            width: 16,
            height: 16,
            borderRadius: 5,
            backgroundColor: accent,
            flexShrink: 0,
          }}
        />
        <span style={{ fontFamily: fontFa, fontSize: 12.5, fontWeight: 800, color: colors.ink }}>{label}</span>
      </div>
      <div
        style={{
          backgroundColor: "white",
          border: `1px solid ${colors.cardBorder}`,
          borderInlineStart: `3px solid ${accent}`,
          borderRadius: 12,
          overflow: "hidden",
        }}
      >
        {items.map((it, i) => {
          const isLineActive = activeLine && activeLine.variant === variant && activeLine.i === i;
          // آفستِ همین خط داخلِ متنِ کاملِ سناریو — با این، زدنِ 🔊ِ همین خط
          // (چه چیزِ دیگه‌ای از قبل در حالِ پخش باشه چه نه) به‌جای خواندنِ
          // تک این یه خط، از دقیقاً همین‌جا وارد پخشِ کلِ سناریو می‌شه و
          // خودش تا آخر ادامه پیدا می‌کنه.
          const lineOffset = lineOffsets && lineOffsets.find((l) => l.variant === variant && l.i === i);
          return (
          <div
            key={i}
            ref={(el) => registerLineRef && registerLineRef(variant, i, el)}
            style={{
              position: "relative",
              padding: "9px 12px",
              borderBottom: i < items.length - 1 ? `1px dashed ${colors.cardBorder}` : "none",
            }}
          >
            {/* ردیفِ متنِ اصلی و هر ردیفِ ترجمه (پایین‌تر) حالا هر کدوم یه
                ردیفِ کامل و هم‌عرض‌ان (نه یکی تو دیگری قایم شده) — این‌جوری
                بلندگوی هر دو همیشه دقیقاً روی یه ستونِ ثابتِ سمت راست
                می‌شینه، هم‌راستا با هم. */}
            <div style={{ display: "flex", alignItems: "flex-start", gap: 8, direction: "rtl" }}>
              {/* بلندگو همیشه اول (یعنی لبه‌ی راست، چون کانتینر rtl‌ه)،
                  بعد بجِ سطح، بعد خودِ متن که فضای باقی‌مونده رو پر می‌کنه. */}
              {SpeakButton && (
                <SpeakButton
                  text={it.en}
                  code="en"
                  color={colors.teal}
                  fullText={fullText}
                  startOffset={lineOffset ? lineOffset.start : undefined}
                  neuralId={`conv:en::${it.en}`}
                  neuralLabel={i18n.t("dialogs_neural_sentence")}
                />
              )}
              <span
                style={{
                  fontFamily: fontLatin,
                  fontSize: 10,
                  fontWeight: 700,
                  color: colors.ink,
                  backgroundColor: colors.goldSoft,
                  borderRadius: 6,
                  padding: "1px 6px",
                  flexShrink: 0,
                }}
              >
                {it.level}
              </span>
              <div style={{ direction: "ltr", textAlign: "left", flex: 1, fontSize: 16, fontWeight: 800, color: mainTextColor, fontFamily: fontLatin }}>
                {/* هایلایتِ «همین الان داره خونده می‌شه» — دقیقاً همون مارکرِ
                    زردِ تنگِ دورِ خودِ متن که تو داستان‌ساز و لغات هست، نه
                    یه باکسِ تمام‌عرض دورِ کل ردیف. */}
                <span
                  style={{
                    backgroundColor: isLineActive ? (highlightColor || READ_MARKER_COLOR) : "transparent",
                    borderRadius: 5,
                    padding: isLineActive ? "2px 4px" : "2px 0",
                    WebkitBoxDecorationBreak: "clone",
                    boxDecorationBreak: "clone",
                    transition: "background-color 0.35s ease",
                  }}
                >
                  {ClickableSentence ? (
                    <ClickableSentence text={it.en} langCode="en" nativeLang={nativeLang} aiSettings={aiSettings} color={mainTextColor} fontFamily={fontLatin} fontWeight={800} fontSize={16} />
                  ) : (
                    it.en
                  )}
                </span>
              </div>
            </div>
            {langCodes.map((code) => {
              const info = translationTextInfo && translationTextInfo[code];
              return (
                <LineTranslation
                  key={code}
                  text={it.en}
                  langCode={code}
                  variant={variant}
                  i={i}
                  knownFa={it.fa}
                  aiSettings={aiSettings}
                  translateFree={translateFree}
                  SpeakButton={SpeakButton}
                  ClickableSentence={ClickableSentence}
                  nativeLang={nativeLang}
                  nativeLabel={nativeLabel}
                  autoScrollActive={autoScrollActive}
                  highlightColor={highlightColor}
                  fullText={info ? info.fullText : ""}
                  lineOffsets={info ? info.lineOffsets : []}
                  isActiveLine={!!(activeTranslationLine && activeTranslationLine.langCode === code && activeTranslationLine.variant === variant && activeTranslationLine.i === i)}
                  onResolved={onResolveTranslation}
                />
              );
            })}
          </div>
          );
        })}
      </div>
    </div>
  );
}

function ScenarioAccordionItem({ sc, isOpen, onToggle, levelFilter, t, nativeLang, nativeLabel, aiSettings, ClickableSentence, SpeakButton, targetLangs, translateFree, activeLine, registerLineRef, highlightColor, fullText, lineOffsets, autoScrollActive, translationTextInfo, activeTranslationLine, onResolveTranslation, isRead, onToggleRead, readDoneColor, readDoneBg }) {
  const filterFn = (arr) => (levelFilter && levelFilter !== "all" ? arr.filter((x) => x.level === levelFilter) : arr);
  const speakerA = filterFn(sc.speakerA);
  const speakerB = filterFn(sc.speakerB);
  if (levelFilter && levelFilter !== "all" && speakerA.length === 0 && speakerB.length === 0) return null;

  return (
    <div
      style={{
        border: `1px solid ${isRead ? READ_DONE_BORDER : colors.cardBorder}`,
        borderRadius: 14,
        marginBottom: 10,
        overflow: "hidden",
        background: isRead ? READ_DONE_GRADIENT : "white",
        boxShadow: isRead ? READ_DONE_SHADOW : "none",
      }}
    >
      <button onClick={onToggle} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 15px", textAlign: "right" }}>
        <div className="flex items-center" style={{ display: "flex", alignItems: "center", gap: 8, flex: 1 }}>
          <span
            onClick={(ev) => {
              ev.stopPropagation();
              onToggleRead && onToggleRead();
            }}
            aria-label={t.toggleRead}
            style={{
              flexShrink: 0,
              width: 20,
              height: 20,
              borderRadius: "50%",
              border: isRead ? `1.6px solid ${READ_DONE_BORDER}` : "1.6px dashed #C8BE95",
              background: isRead ? READ_DONE_CHECK_GRADIENT : "transparent",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {isRead && <Check size={13} color="white" strokeWidth={3} />}
          </span>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: fontFa, fontWeight: 700, fontSize: 14, color: colors.ink }}>{sc.scenario}</div>
            {sc.context && !isOpen && (
              <div style={{ fontFamily: fontFa, fontSize: 11.5, color: isRead ? colors.ink : colors.inkSoft, opacity: isRead ? 0.75 : 1, marginTop: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {sc.context}
              </div>
            )}
          </div>
        </div>
        <ChevronDown size={18} color={colors.teal} style={{ transform: isOpen ? "rotate(180deg)" : "none", transition: "transform .15s", flexShrink: 0, marginRight: 8 }} />
      </button>
      {isOpen && (
        <div style={{ padding: "0 15px 15px" }}>
          {sc.context && <div style={{ fontFamily: fontFa, fontSize: 12, color: colors.inkSoft, marginBottom: 4 }}>{sc.context}</div>}
          <ConversationBox items={speakerA} variant="hear" label={t.youHear} nativeLang={nativeLang} nativeLabel={nativeLabel} aiSettings={aiSettings} ClickableSentence={ClickableSentence} SpeakButton={SpeakButton} targetLangs={targetLangs} translateFree={translateFree} activeLine={isOpen ? activeLine : null} registerLineRef={isOpen ? registerLineRef : undefined} highlightColor={highlightColor} fullText={fullText} lineOffsets={lineOffsets} autoScrollActive={autoScrollActive} translationTextInfo={translationTextInfo} activeTranslationLine={isOpen ? activeTranslationLine : null} onResolveTranslation={onResolveTranslation} />
          <ConversationBox items={speakerB} variant="say" label={t.youSay} nativeLang={nativeLang} nativeLabel={nativeLabel} aiSettings={aiSettings} ClickableSentence={ClickableSentence} SpeakButton={SpeakButton} targetLangs={targetLangs} translateFree={translateFree} activeLine={isOpen ? activeLine : null} registerLineRef={isOpen ? registerLineRef : undefined} highlightColor={highlightColor} fullText={fullText} lineOffsets={lineOffsets} autoScrollActive={autoScrollActive} translationTextInfo={translationTextInfo} activeTranslationLine={isOpen ? activeTranslationLine : null} onResolveTranslation={onResolveTranslation} />
        </div>
      )}
    </div>
  );
}

// موضوع/سناریوی بازِ همین‌الان — بیرونِ کامپوننت نگه داشته می‌شه چون این تب
// (برخلاف تب‌های داستان/گرامر که با display:none زنده می‌مونن) با تعویضِ تب
// کاملاً unmount می‌شه؛ بدونِ این، هر برگشت به تب مکالمات، state لوکال از نو
// null می‌شد و کاربر می‌افتاد رو لیستِ موضوعات — حتی وسطِ پخشِ صدا. با
// remount از همین‌جا شروع می‌شه و افکتِ activeLine/scrollIntoView پایین‌تر
// (که به speechController گوش می‌ده) خودش کاربر رو دقیقاً به همون خطِ در
// حالِ پخش می‌بره.
let lastConversationsNav = { topic: null, scenario: null };

export default function DailyConversationsTab({
  data,
  query,
  uiLang: uiLangProp,
  nativeLang,
  nativeLabel,
  aiSettings,
  ClickableSentence,
  SpeakButton,
  targetLangs,
  translateFree,
  retranslateLine,
  getCachedTranslationMap,
  levelFilter,
  speechController,
  onFullTextChange,
  autoScrollActive,
  highlightColor,
  loadReadWordIds,
  saveReadWordIds,
  wordsPageSize,
  readDoneColor,
  readDoneBg,
}) {
  const uiLang = uiLangProp || (nativeLang === "fa" ? "fa" : "en");
  const [activeTopic, setActiveTopic] = useState(() => lastConversationsNav.topic);
  const [openScenario, setOpenScenario] = useState(() => lastConversationsNav.scenario);
  useEffect(() => {
    lastConversationsNav = { topic: activeTopic, scenario: openScenario };
  }, [activeTopic, openScenario]);

  const t = convStrings(uiLang);
  const tt = i18n.getFixedT(uiLang || "fa");
  const fmtNum = (n) => (isRtlUi(uiLang) ? Number(n).toLocaleString("fa-IR") : String(n));

  const filterByLevel = (arr) => (levelFilter && levelFilter !== "all" ? arr.filter((x) => x.level === levelFilter) : arr);

  const dataByTopic = useMemo(() => {
    const map = {};
    data.forEach((tp) => (map[tp.topic] = tp));
    return map;
  }, [data]);

  // ترجمه‌ی هر خطِ مکالمه به زبان‌های غیر از فارسی/انگلیسی، بر خلافِ لغات،
  // فقط لحظه‌ای (وقتی کاربر واقعاً همون سناریو رو باز می‌کنه) گرفته و توی
  // IndexedDB کش می‌شه — نه یه فیلدِ ثابتِ توی خودِ دیتا. برای اینکه جستجو
  // بتونه رویِ همون ترجمه‌های از قبل کش‌شده هم (بدونِ درخواستِ شبکه‌ی تازه
  // برای صدها خط) جواب بده، وقتی کاربر چیزی تایپ می‌کنه، کلِ کشِ هر زبانِ
  // مقصدِ انتخاب‌شده (غیر از فارسی/انگلیسی که خودِ دیتا داره) رو یه‌بار
  // می‌خونیم و محلی نگه می‌داریم. طبیعتاً فقط جمله‌هایی که قبلاً یه‌جایی
  // (باز کردنِ همون سناریو) ترجمه و کش شده باشن پیدا می‌شن — نه هر جمله‌ای
  // که هنوز اصلاً دیده نشده.
  const [extraLangMaps, setExtraLangMaps] = useState({}); // { [langCode]: Map<en, translation> }
  useEffect(() => {
    if (!getCachedTranslationMap || !query || !query.trim()) return;
    // نکته: "fa" همیشه حذف می‌شه چون it.fa از قبل توی خودِ دیتاست و مستقیم
    // (بدونِ نیاز به کش) توی itemMatchesQuery چک می‌شه؛ ولی برخلافِ قبل،
    // اگه زبانِ مادریِ کاربر چیزِ دیگه‌ای (نه فارسی) باشه، الان اون هم جزوِ
    // این لیست میاد — وگرنه جستجو فقط رویِ زبان‌های یادگیری کار می‌کرد، نه
    // رویِ ترجمه‌ی زبانِ مادریِ واقعیِ کاربر.
    const codes = Array.from(new Set(buildDisplayLangCodes(nativeLang, targetLangs))).filter((c) => c !== "en" && c !== "fa");
    if (!codes.length) return;
    let cancelled = false;
    const timer = setTimeout(() => {
      codes.forEach((code) => {
        getCachedTranslationMap(code, "en").then((map) => {
          if (!cancelled) setExtraLangMaps((prev) => ({ ...prev, [code]: map }));
        });
      });
    }, 250); // دبانس — تا وسطِ تایپ‌کردن، هر ضربه‌ی کیبورد یه اسکنِ کامل از کش نسازه
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query, nativeLang, targetLangs, getCachedTranslationMap]);

  // یه خطِ مکالمه، صرف‌نظر از اینکه it.t (زبان‌های ثابتِ توی دیتا) داره یا
  // نه، آیا با عبارتِ جستجو‌شده (q) — چه تو متنِ اصلیِ انگلیسی، چه فارسیِ
  // ثابتِ دیتا، چه هر ترجمه‌ی از قبل کش‌شده‌ی extraLangMaps — مطابقت داره؟
  const itemMatchesQuery = (it, q, rawQuery) => {
    if (it.t) {
      return Object.values(it.t).some((v) => typeof v === "string" && v.toLowerCase().includes(q));
    }
    if (it.en && it.en.toLowerCase().includes(q)) return true;
    if (it.fa && it.fa.includes(rawQuery)) return true;
    for (const code of Object.keys(extraLangMaps)) {
      const val = extraLangMaps[code] && extraLangMaps[code].get(it.en);
      if (val && val.toLowerCase().includes(q)) return true;
    }
    return false;
  };

  // -----------------------------------------------------------------------
  // بازه‌ی نمایش («از # تا #») + ردیابیِ خوانده‌شده — همون الگویی که تب‌های
  // لغات/داستان‌ساز/گرامر دارن. اینجا دو سطح جدا ردیابی می‌شه: خودِ
  // موضوع‌ها (کارت‌های توری بالا) و سناریوهای داخلِ هر موضوع، چون شمارشِ
  // «خوانده‌شده» باید هر بار زنده از رویِ همین دو Set حساب بشه، نه یه
  // عددِ ثابت.
  const [topicReadIds, setTopicReadIds] = useState(() => loadReadWordIds("dailyConvTopics"));
  const toggleTopicRead = (en) => {
    setTopicReadIds((prev) => {
      const next = new Set(prev);
      if (next.has(en)) next.delete(en);
      else next.add(en);
      saveReadWordIds("dailyConvTopics", next);
      return next;
    });
  };
  const markTopicRangeRead = (items, read) => {
    setTopicReadIds((prev) => {
      const next = new Set(prev);
      items.forEach((m) => {
        if (read) next.add(m.en);
        else next.delete(m.en);
      });
      saveReadWordIds("dailyConvTopics", next);
      return next;
    });
  };
  const [topicRangeInput, setTopicRangeInput] = useState({ from: "", to: "" });

  const [scenarioReadIds, setScenarioReadIds] = useState(() => loadReadWordIds("dailyConvScenarios"));
  const toggleScenarioRead = (topicEn, i) => {
    const id = `${topicEn}::${i}`;
    setScenarioReadIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      saveReadWordIds("dailyConvScenarios", next);
      return next;
    });
  };

  const filteredMeta = useMemo(() => {
    const all = TOPIC_META_LIST.map(([en, fa, icon, enLabel]) => ({ en, fa, icon, enLabel: enLabel || en, labelKey: topicLabelKey(enLabel || en) }));
    if (!query || !query.trim()) return all;
    const q = query.trim().toLowerCase();
    return all.filter((m) => {
      if (m.fa.includes(query.trim()) || m.en.toLowerCase().includes(q) || topicLabel(m, uiLang).toLowerCase().includes(q)) return true;
      const d = dataByTopic[m.en];
      if (!d) return false;
      return d.scenarios.some((sc) => {
        if (sc.scenario && sc.scenario.toLowerCase().includes(q)) return true;
        return [...(sc.speakerA || []), ...(sc.speakerB || [])].some((it) => itemMatchesQuery(it, q, query.trim()));
      });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, dataByTopic, extraLangMaps, uiLang]);

  const activeTopicData = activeTopic ? dataByTopic[activeTopic] : null;

  // خطوطِ قابل‌خوندنِ سناریوی همین‌الان بازشده — دقیقاً همون ترتیبی که
  // ConversationBox نشون می‌ده (اول «می‌شنوی»، بعد «می‌گی»). این‌ها منبعِ
  // متنِ دکمه‌ی 🔊ِ «خواندنِ کل متن» روی نوارِ پلیرن.
  const openScenarioData = activeTopicData && openScenario != null ? activeTopicData.scenarios[openScenario] : null;
  const readableLines = useMemo(() => {
    if (!openScenarioData) return [];
    // هر خطِ مکالمه رو برای مصرفِ TTS/هایلایت (نه نمایش — نمایش همچنان از
    // رویِ it.en خامِ خودش انجام می‌شه) با یه نقطه‌ی پایانی تضمین می‌کنیم،
    // اگه خودش قبلاً با یکی از علامت‌های‌نگارشیِ جمله تموم نشده باشه. بدونِ
    // این، وقتی چند خطِ بدونِ‌نقطه پشتِ‌سرِهم فقط با یه فاصله به fullText
    // می‌چسبیدن، splitSentencesRaw نمی‌تونست بفهمه کجا یه خط تموم و خطِ
    // بعدی شروع می‌شه؛ نتیجه‌ش یا ادغامِ چند خط توی یه «جمله»ی مصنوعیِ خیلی
    // بلند بود، یا (وقتی این ادغام از حدِ ۴۰کلمه رد می‌شد) تکه‌تکه‌شدنِ
    // دلبخواهی که حالتِ تکرار روش گیر می‌کرد.
    const a = filterByLevel(openScenarioData.speakerA || []).map((it, i) => ({ text: ensureSentenceEnd(it.en), variant: "hear", i }));
    const b = filterByLevel(openScenarioData.speakerB || []).map((it, i) => ({ text: ensureSentenceEnd(it.en), variant: "say", i }));
    return [...a, ...b];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openScenarioData, levelFilter]);

  const fullText = readableLines.map((l) => l.text).join(" ");

  const lineOffsets = useMemo(() => {
    let offset = 0;
    return readableLines.map((l) => {
      const start = offset;
      offset += l.text.length + 1; // فاصله‌ی join(" ")
      return { variant: l.variant, i: l.i, start, end: start + l.text.length };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fullText]);

  // مرزهایِ دقیقِ شروعِ هر خطِ مکالمه، برای دادن به speechController به‌عنوانِ
  // sentenceBoundaries — این تضمین می‌کنه دو خطِ مکالمه‌ی جدا، حتی اگه علامتِ
  // نگارشیِ خودِ splitSentencesRaw هم قاطی‌شون بشه، هیچ‌وقت توی یه «جمله»/
  // چانکِ TTS واحد ادغام نشن (دقیقاً همون مکانیزمی که StoryBuilder برایِ
  // storySentenceBoundaries استفاده می‌کنه).
  const sentenceBoundaries = useMemo(() => lineOffsets.map((l) => l.start), [lineOffsets]);

  // خطی که همین الان، در حینِ پخشِ «کل متن» از روی پلیر، داره خونده می‌شه —
  // فقط برای اسکرولِ خودکار استفاده می‌شه (هایلایتِ بصری نداره).
  const [activeLine, setActiveLine] = useState(null); // {variant, i} | null

  // موقع رفتن به سناریو یا موضوعِ دیگه، نشانگرِ خط قدیمی رو پاک کن. این افکت
  // عمداً *قبل* از افکتِ محاسبه‌ی activeLine (پایین‌تر) اومده: هر دو افکت با
  // تغییرِ activeTopic/openScenario یا موقعِ mount با هم اجرا می‌شن، و چون
  // ترتیبِ اجرای افکت‌ها همون ترتیبِ نوشتنشونه، اگه این‌یکی زودتر باشه،
  // setActiveLine(null) این افکت با setActiveLine(found) افکتِ بعدی
  // overwrite نمی‌شه — وگرنه دقیقاً همون لحظه‌ی remount (برگشت به این تب
  // وسطِ پخش) که باید activeLine درست محاسبه بشه، این افکت با اجرا شدنِ
  // بعد از اون، دوباره می‌ذاشتش رو null.
  useEffect(() => {
    setActiveLine(null);
  }, [activeTopic, openScenario]);

  useEffect(() => {
    if (!speechController) return;
    const myKey = `en-US::${fullText}`;
    const update = (state) => {
      if (!fullText || state.key !== myKey || state.status === "idle") {
        setActiveLine(null);
        return;
      }
      const offset = speechController.getCharOffset();
      let found = lineOffsets[0] || null;
      for (const l of lineOffsets) {
        if (offset >= l.start) found = l;
        else break;
      }
      setActiveLine((prev) => {
        const next = found ? { variant: found.variant, i: found.i } : null;
        if (prev && next && prev.variant === next.variant && prev.i === next.i) return prev;
        return next;
      });
    };
    update(speechController.getState());
    // chunkIndex دقیقاً همون لحظه‌ای که خطِ بعدی شروع می‌شه آپدیت می‌شه (نه
    // با تخمین)، پس دیگه نیازی به polling نیست.
    return speechController.subscribe(update);
  }, [fullText, lineOffsets, speechController]);

  // -------------------------------------------------------------------------
  // «خواندنِ پیوسته‌ی ترجمه‌ها» — دقیقاً همون سیستمِ متنِ اصلیِ انگلیسی
  // (fullText + lineOffsets + activeLine + اسکرولِ خودکار) بالاتر، اما این‌بار
  // برای هر زبانِ ترجمه‌ی هدف جدا جدا. چون ترجمه‌ی هر خط lazy و async لود
  // می‌شه (LineTranslation)، نمی‌شه از قبل fullText رو ساخت؛ به‌جاش هر خط،
  // به محضِ آماده‌شدنِ مقدارش، از طریق onResolveTranslation به بالا خبر
  // می‌ده و اینجا، از رویِ مقادیرِ جمع‌شده، fullText/offsetِ هر زبان
  // ساخته می‌شه.
  const [translationValues, setTranslationValues] = useState({}); // { [langCode]: { [`${variant}-${i}`]: text } }
  const reportTranslation = useCallback((langCode, variant, i, value) => {
    setTranslationValues((prev) => {
      const langMap = prev[langCode] || {};
      const key = `${variant}-${i}`;
      if (langMap[key] === value) return prev;
      return { ...prev, [langCode]: { ...langMap, [key]: value } };
    });
  }, []);
  useEffect(() => {
    setTranslationValues({});
  }, [activeTopic, openScenario]);

  const targetLangCodes = useMemo(
    () => buildDisplayLangCodes(nativeLang, targetLangs),
    [nativeLang, targetLangs]
  );

  const translationTextInfo = useMemo(() => {
    const info = {};
    targetLangCodes.forEach((code) => {
      const langMap = translationValues[code] || {};
      let offset = 0;
      const parts = [];
      const offsets = [];
      readableLines.forEach((l) => {
        const rawVal = langMap[`${l.variant}-${l.i}`];
        if (!rawVal) return;
        const val = ensureSentenceEnd(rawVal);
        const start = offset;
        parts.push(val);
        offset += val.length + 1; // فاصله‌ی join(" ")
        offsets.push({ variant: l.variant, i: l.i, start, end: start + val.length });
      });
      info[code] = { fullText: parts.join(" "), lineOffsets: offsets, sentenceBoundaries: offsets.map((o) => o.start) };
    });
    return info;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetLangCodes, translationValues, readableLines]);

  // خطِ ترجمه‌ای که همین الان، در حینِ پخشِ پیوسته‌ی ترجمه‌های یک زبان، داره
  // خونده می‌شه — {langCode, variant, i} | null. دقیقاً همون الگویی که
  // activeLine بالاتر برای متنِ انگلیسی داره.
  const [activeTranslationLine, setActiveTranslationLine] = useState(null);

  useEffect(() => {
    setActiveTranslationLine(null);
  }, [activeTopic, openScenario]);

  // 🐛 باگِ «تکرار/پلیرِ ترجمه‌ها وصل نیست»: قبلاً به‌محضِ محاسبه‌ی fullText
  // (متنِ اصلیِ انگلیسی)، یه‌بار onFullTextChange با همون متن صدا زده
  // می‌شد و دیگه هیچ‌وقت عوض نمی‌شد — یعنی نوارِ پلیرِ سراسریِ پایینِ
  // صفحه (دکمه‌های بازگشت‌به‌اول، جمله‌ی بعد/قبل، تکرارِ سراسری، دکمه‌ی
  // مرکزیِ پخش وقتی چیزی پخش نیست) همیشه فقط متنِ انگلیسی رو می‌شناخت،
  // حتی وقتی کاربر داشت یه ترجمه رو پخشِ پیوسته می‌کرد. نتیجه: زدنِ
  // «بازگشت‌به‌اول» وسطِ پخشِ یه ترجمه، به‌جایِ ریستارت‌کردنِ همون
  // ترجمه، متنِ انگلیسی رو از اول شروع می‌کرد. الان همین افکت (که
  // زبانِ ترجمه‌ی در حالِ پخش رو تشخیص می‌ده) هر بار وضعیتِ پخش عوض
  // بشه، onFullTextChange رو هم با متن/زبانِ *واقعاً در حالِ پخش*
  // صدا می‌زنه — ترجمه‌ی فعال اگه چیزی پخش می‌شه، وگرنه (idle یا
  // درحالِ پخشِ خودِ متنِ انگلیسی) برمی‌گرده رو پیش‌فرضِ انگلیسی.
  useEffect(() => {
    if (!speechController) {
      if (onFullTextChange) onFullTextChange({ text: fullText, code: "en", sentenceBoundaries });
      return;
    }
    const update = (state) => {
      if (!state.key || state.status === "idle") {
        setActiveTranslationLine(null);
        if (onFullTextChange) onFullTextChange({ text: fullText, code: "en", sentenceBoundaries });
        return;
      }
      for (const code of targetLangCodes) {
        const info = translationTextInfo[code];
        if (!info || !info.fullText) continue;
        const myKey = `${TTS_LOCALE_MINI[code] || "en-US"}::${info.fullText}`;
        if (state.key !== myKey) continue;
        // همین الان ترجمه‌ی همینِ زبان در حالِ پخشِ پیوسته‌ست — نوارِ
        // پلیرِ سراسری رو هم به همینِ ترجمه وصل کن، نه به متنِ انگلیسی.
        if (onFullTextChange) onFullTextChange({ text: info.fullText, code, sentenceBoundaries: info.sentenceBoundaries });
        const offset = speechController.getCharOffset();
        let found = info.lineOffsets[0] || null;
        for (const l of info.lineOffsets) {
          if (offset >= l.start) found = l;
          else break;
        }
        if (found) {
          setActiveTranslationLine((prev) => {
            if (prev && prev.langCode === code && prev.variant === found.variant && prev.i === found.i) return prev;
            return { langCode: code, variant: found.variant, i: found.i };
          });
        }
        return;
      }
      // هیچ ترجمه‌ای در حالِ پخش نیست (مثلاً خودِ متنِ انگلیسی در حالِ
      // پخشه) — پلیرِ سراسری رو به پیش‌فرضِ انگلیسی برگردون.
      setActiveTranslationLine(null);
      if (onFullTextChange) onFullTextChange({ text: fullText, code: "en", sentenceBoundaries });
    };
    update(speechController.getState());
    return speechController.subscribe(update);
  }, [targetLangCodes, translationTextInfo, speechController, fullText, sentenceBoundaries, onFullTextChange]);

  const lineRefs = useRef({});
  const registerLineRef = (variant, i, el) => {
    lineRefs.current[`${variant}-${i}`] = el;
  };
  useEffect(() => {
    if (!autoScrollActive || !activeLine) return;
    const node = lineRefs.current[`${activeLine.variant}-${activeLine.i}`];
    if (node && node.scrollIntoView) {
      node.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [autoScrollActive, activeLine?.variant, activeLine?.i]);

  // جستجوی سراسری روی کلِ مکالمات (نه فقط اسمِ موضوع‌ها): وقتی کاربر عبارتی
  // تایپ می‌کنه، چه تو صفحه‌ی موضوعات باشه چه داخل یه موضوعِ بازشده، همه‌ی
  // خط‌های همه‌ی سناریوهای همه‌ی موضوعات (هم متنِ انگلیسی هم ترجمه‌ی فارسیِ
  // ذخیره‌شده‌شون) رو می‌گرده و نتیجه رو مستقل از activeTopic نشون می‌ده.
  // قبلاً وقتی داخلِ یه موضوع بودی، سرچ اصلاً به محتوای بازشده اعمال
  // نمی‌شد و همیشه همون موضوعِ باز نشون داده می‌شد — همین باعث می‌شد سرچ
  // «کاری نکنه».
  const searchResults = useMemo(() => {
    if (!query || !query.trim()) return null;
    const q = query.trim().toLowerCase();
    const results = [];
    data.forEach((tp) => {
      const meta = TOPIC_META[tp.topic] || { fa: tp.topic, icon: MessageCircle };
      (tp.scenarios || []).forEach((sc) => {
        const scenarioHit = sc.scenario && sc.scenario.toLowerCase().includes(q);
        [["speakerA", "hear"], ["speakerB", "say"]].forEach(([key, variant]) => {
          (sc[key] || []).forEach((it) => {
            const hit = scenarioHit || itemMatchesQuery(it, q, query.trim());
            if (hit) {
              results.push({ topicLabel: topicLabel(meta, uiLang) || tp.topic, icon: meta.icon, scenario: sc.scenario, item: it, variant });
            }
          });
        });
      });
    });
    return results;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, data, extraLangMaps, uiLang]);

  if (searchResults) {
    return (
      <div>
        {searchResults.length === 0 ? (
          <div style={{ textAlign: "center", color: colors.inkSoft, padding: 30, fontSize: 13.5, fontFamily: fontFa }}>{t.noResults}</div>
        ) : (
          searchResults.map((r, i) => (
            <div key={i} style={{ marginBottom: 14 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11.5, color: colors.inkSoft, fontFamily: isRtlUi(uiLang) ? fontFa : fontLatin, marginBottom: 5 }}>
                <r.icon size={13} strokeWidth={2} color={colors.inkSoft} style={{ flexShrink: 0 }} />
                <span>{r.topicLabel} · {r.scenario}</span>
              </div>
              <ConversationBox
                items={[r.item]}
                variant={r.variant}
                label={r.variant === "hear" ? t.youHear : t.youSay}
                nativeLang={nativeLang}
                aiSettings={aiSettings}
                ClickableSentence={ClickableSentence}
                SpeakButton={SpeakButton}
                targetLangs={targetLangs}
                translateFree={translateFree}
                speechController={speechController}
                autoScrollActive={autoScrollActive}
                highlightColor={highlightColor}
              />
            </div>
          ))
        )}
      </div>
    );
  }

  return (
    <RetranslateContext.Provider value={retranslateLine || null}>
    <div>
      {/* شبکه‌ی کارت‌های موضوعی */}
      {!activeTopic && (() => {
        const total = filteredMeta.length;
        const defaultTo = Math.min(total, wordsPageSize) || total || 1;
        const parsedFrom = parseInt(topicRangeInput.from, 10);
        const parsedTo = parseInt(topicRangeInput.to, 10);
        const effFrom = Number.isNaN(parsedFrom) ? 1 : parsedFrom;
        const effTo = Number.isNaN(parsedTo) ? defaultTo : parsedTo;
        const clampedFrom = Math.min(Math.max(1, effFrom), Math.max(total, 1));
        const clampedTo = Math.min(Math.max(clampedFrom, effTo), total || clampedFrom);
        const visibleMeta = filteredMeta.slice(clampedFrom - 1, clampedTo);
        const readCountInRange = visibleMeta.filter((m) => topicReadIds.has(m.en)).length;
        const readCountTotal = filteredMeta.filter((m) => topicReadIds.has(m.en)).length;
        return (
          <>
            {total > 0 && (() => {
              const pct = total ? (readCountTotal / total) * 100 : 0;
              return (
                <div
                  style={{
                    background: "#fff",
                    border: `1px solid ${colors.cardBorder}`,
                    borderRadius: 18,
                    padding: 16,
                    marginBottom: 18,
                    boxShadow: "0 10px 24px -12px rgba(18,46,42,.28)",
                  }}
                >
                  {/* ردیفِ بازه («۱ تا ۴۰ / از مجموعِ ۴۰») — دقیقاً همون
                      .progress-top طرحِ مرجع، با این تفاوت که عدد‌ها اینجا
                      قابلِ‌ویرایشن (کاربر می‌تونه بازه‌ی نمایش رو خودش تنظیم کنه). */}
                  <div className="flex items-center gap-2 flex-wrap" style={{ direction: isRtlUi(uiLang) ? "rtl" : "ltr", marginBottom: 12 }}>
                    <input
                      type="number"
                      min={1}
                      max={total}
                      value={topicRangeInput.from}
                      placeholder="1"
                      onChange={(ev) => setTopicRangeInput((prev) => ({ ...prev, from: ev.target.value }))}
                      onBlur={() => {
                        if (topicRangeInput.from !== "") setTopicRangeInput((prev) => ({ ...prev, from: String(clampedFrom) }));
                      }}
                      style={{ width: 44, padding: "4px 4px", borderRadius: 6, border: `1px solid ${colors.cardBorder}`, fontSize: 13, fontWeight: 700, color: colors.teal, textAlign: "center" }}
                    />
                    <span style={{ fontSize: 15, fontWeight: 700, color: colors.teal }}>{tt("dialogs_range_to")}</span>
                    <input
                      type="number"
                      min={1}
                      max={total}
                      value={topicRangeInput.to}
                      placeholder={String(defaultTo)}
                      onChange={(ev) => setTopicRangeInput((prev) => ({ ...prev, to: ev.target.value }))}
                      onBlur={() => {
                        if (topicRangeInput.to !== "") setTopicRangeInput((prev) => ({ ...prev, to: String(clampedTo) }));
                      }}
                      style={{ width: 44, padding: "4px 4px", borderRadius: 6, border: `1px solid ${colors.cardBorder}`, fontSize: 13, fontWeight: 700, color: colors.teal, textAlign: "center" }}
                    />
                    <span style={{ fontSize: 13, color: colors.inkSoft, fontWeight: 600, marginRight: "auto" }}>
                      {tt("dialogs_topics_label")}{" "}
                      <span style={{ fontWeight: 400 }}>{tt("dialogs_topics_of_total", { total: fmtNum(total) })}</span>
                    </span>
                  </div>

                  {/* نوارِ پیشرفتِ کلیِ همه‌ی موضوع‌ها — گرادیانتِ سبز→طلایی،
                      دقیقاً مثلِ .progress-meter i طرحِ مرجع. */}
                  <div style={{ height: 8, borderRadius: 99, background: colors.paperDark, overflow: "hidden", marginBottom: 12 }}>
                    <div
                      style={{
                        display: "block",
                        height: "100%",
                        width: `${pct}%`,
                        background: `linear-gradient(90deg, ${colors.teal}, ${colors.gold})`,
                        transition: "width .3s ease",
                      }}
                    />
                  </div>

                  <div className="flex items-center gap-2 flex-wrap" style={{ direction: isRtlUi(uiLang) ? "rtl" : "ltr" }}>
                    <span style={{ fontSize: 13, color: "#2E7D6C", fontWeight: 600 }}>
                      {tt("dialogs_read_progress", { read: fmtNum(readCountTotal), total: fmtNum(total), range_read: fmtNum(readCountInRange), range_total: fmtNum(visibleMeta.length) })}
                    </span>
                  </div>

                  {/* دکمه‌های عمل — دقیقاً همون .btn-ghost / .btn-ghost.mark-all
                      طرحِ مرجع (سبزِ کم‌رنگ برای «همه به خوانده‌شده»، کِرمِ
                      خنثی برای «پاک‌کردن»). */}
                  <div className="flex items-center gap-2 flex-wrap" style={{ direction: isRtlUi(uiLang) ? "rtl" : "ltr", marginTop: 12 }}>
                    <button
                      type="button"
                      onClick={() => markTopicRangeRead(visibleMeta, true)}
                      style={{
                        fontFamily: isRtlUi(uiLang) ? fontFa : fontLatin,
                        fontSize: 12.5,
                        fontWeight: 600,
                        padding: "8px 12px",
                        borderRadius: 11,
                        border: "1px solid #CFE6DF",
                        background: "#EAF4F1",
                        color: colors.teal,
                        cursor: "pointer",
                      }}
                    >
                      {tt("dialogs_mark_range_read")}
                    </button>
                    <button
                      type="button"
                      onClick={() => markTopicRangeRead(visibleMeta, false)}
                      style={{
                        fontFamily: isRtlUi(uiLang) ? fontFa : fontLatin,
                        fontSize: 12.5,
                        fontWeight: 600,
                        padding: "8px 12px",
                        borderRadius: 11,
                        border: `1px solid ${colors.cardBorder}`,
                        background: colors.paper,
                        color: colors.teal,
                        cursor: "pointer",
                      }}
                    >
                      {tt("dialogs_clear_range")}
                    </button>
                  </div>
                </div>
              );
            })()}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
              {visibleMeta.map((m, i) => (
                <TopicCard
                  key={m.en}
                  meta={m}
                  index={i}
                  uiLang={uiLang}
                  hasData={!!dataByTopic[m.en]}
                  isRead={topicReadIds.has(m.en)}
                  onToggleRead={() => toggleTopicRead(m.en)}
                  readDoneColor={readDoneColor}
                  readDoneBg={readDoneBg}
                  onClick={() => {
                    setActiveTopic(m.en);
                    setOpenScenario(0);
                  }}
                />
              ))}
              {filteredMeta.length === 0 && (
                <div style={{ gridColumn: "1 / -1", textAlign: "center", color: colors.inkSoft, padding: 30, fontSize: 13.5, fontFamily: fontFa }}>{t.noResults}</div>
              )}
            </div>
          </>
        );
      })()}

      {/* آکاردئون سناریوهای موضوع انتخاب‌شده */}
      {activeTopic && (
        <div style={{ paddingTop: 6 }}>
          <button onClick={() => setActiveTopic(null)} style={{ display: "flex", alignItems: "center", gap: 6, color: colors.teal, fontSize: 13, fontWeight: 700, fontFamily: isRtlUi(uiLang) ? fontFa : fontLatin, marginBottom: 14 }}>
            ← {t.backToTopics}
          </button>

          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
            {(() => {
              const HeaderIcon = TOPIC_META[activeTopic]?.icon || MessageCircle;
              return <HeaderIcon size={22} strokeWidth={2} color={colors.teal} />;
            })()}
            <span style={{ fontWeight: 800, fontSize: 16, color: colors.ink, fontFamily: isRtlUi(uiLang) ? fontFa : fontLatin }}>
              {TOPIC_META[activeTopic] ? topicLabel(TOPIC_META[activeTopic], uiLang) : activeTopic}
            </span>
          </div>

          {activeTopicData ? (
            activeTopicData.scenarios.map((sc, i) => (
              <ScenarioAccordionItem
                key={i}
                sc={sc}
                t={t}
                levelFilter={levelFilter}
                isOpen={openScenario === i}
                onToggle={() => setOpenScenario(openScenario === i ? null : i)}
                isRead={scenarioReadIds.has(`${activeTopic}::${i}`)}
                onToggleRead={() => toggleScenarioRead(activeTopic, i)}
                readDoneColor={readDoneColor}
                readDoneBg={readDoneBg}
                nativeLang={nativeLang}
                nativeLabel={nativeLabel}
                aiSettings={aiSettings}
                ClickableSentence={ClickableSentence}
                SpeakButton={SpeakButton}
                targetLangs={targetLangs}
                translateFree={translateFree}
                activeLine={activeLine}
                registerLineRef={registerLineRef}
                highlightColor={highlightColor}
                fullText={fullText}
                lineOffsets={lineOffsets}
                autoScrollActive={autoScrollActive}
                translationTextInfo={translationTextInfo}
                activeTranslationLine={activeTranslationLine}
                onResolveTranslation={reportTranslation}
              />
            ))
          ) : (
            <div style={{ textAlign: "center", color: colors.inkSoft, padding: 30, fontSize: 13.5, fontFamily: fontFa }}>{t.comingSoon}</div>
          )}
        </div>
      )}
    </div>
    </RetranslateContext.Provider>
  );
}
