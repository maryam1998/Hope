import React, { useState, useEffect, useMemo, useRef } from "react";
import { createPortal } from "react-dom";

/* =============================================================================
   🧬 مسیرهای عصبی (Neural Paths)
   -----------------------------------------------------------------------------
   ایده: هر بار که کاربر یه لغت/جمله رو (چه متنِ اصلی، چه هر کدوم از
   ترجمه‌هاش) از طریقِ پلیر پخش می‌کنه یا دستی ثبت می‌کنه، یه «تکرار» ثبت
   می‌شه. از رویِ روزهای متفاوتی که توش تکرار ثبت شده، «رشته‌های عصبی»
   ساخته می‌شه؛ وقتی تعدادِ روزهای متفاوت به حدِ کافی برسه، مرحله از
   «یادگیری» به «تثبیت» می‌ره.

   هر آیتم (لغت/جمله/ترجمه) با یه id ثابت شناسایی می‌شه — مثلاً
   `word:12:en` یا `conv:fa::سلام، حالت چطوره؟`. همین id باعث می‌شه متنِ
   اصلی و هر زبانِ ترجمه، هرکدوم مسیرِ عصبیِ جداگانه‌ی خودشون رو داشته باشن.

   ذخیره‌سازی فعلاً فقط localStorage (مستقل از بقیه‌ی اپ) — ساختارش ساده و
   صاف نگه داشته شده که بعداً راحت بشه به چرخه‌ی سینکِ ابری هم اضافه‌ش کرد.
   ============================================================================= */

const STORE_KEY = "phrasebook-neural-log-v1";
// دفترچه‌ی رشته‌های عصبی: هر آیتم یه {logs:{}, habitFormed:false} داره —
// جدا از رویدادهای بالا (که فقط برای آمار/تقویم نگه داشته می‌شن).
const LEDGER_KEY = "phrasebook-neural-ledger-v1";
// سقفِ نمایشی برای رنگِ نورونِ «عادت» — تعدادِ واقعیِ رشته‌ها می‌تونه بیشتر باشه
const NEURAL_FIBER_CAP = 10;

let cache = null;
let ledgerCache = null;
const listeners = new Set();

function loadStore() {
  if (cache) return cache;
  try {
    cache = JSON.parse(window.localStorage.getItem(STORE_KEY) || "{}");
  } catch {
    cache = {};
  }
  return cache;
}

function persist() {
  try {
    window.localStorage.setItem(STORE_KEY, JSON.stringify(cache));
  } catch {}
  listeners.forEach((fn) => {
    try {
      fn();
    } catch {}
  });
}

if (typeof window !== "undefined") {
  window.addEventListener("storage", (e) => {
    if (e.key === STORE_KEY) {
      cache = null;
      loadStore();
    } else if (e.key === LEDGER_KEY) {
      ledgerCache = null;
      loadLedger();
    } else {
      return;
    }
    listeners.forEach((fn) => {
      try {
        fn();
      } catch {}
    });
  });
}

/** یه تکرار (یا چند تکرار) رو برای یه آیتم ثبت می‌کنه.
 *  opts: { count=1, at=Date.now(), source: "player" | "manual" }
 */
export function recordNeuralRepeat(id, opts) {
  if (!id) return;
  const store = loadStore();
  const list = store[id] || (store[id] = []);
  const count = Math.max(1, Math.min(999, Number((opts && opts.count) || 1)));
  const ts = (opts && opts.at) || Date.now();
  const source = opts && opts.source === "manual" ? "m" : "p";
  for (let i = 0; i < count; i++) list.push({ t: ts, s: source });
  // یه فایلِ در حالِ رشد بی‌نهایت نمی‌خوایم؛ فعلاً سقفِ منطقی برای هر آیتم.
  if (list.length > 2000) list.splice(0, list.length - 2000);
  persist();
}

export function getNeuralEvents(id) {
  return id ? loadStore()[id] || [] : [];
}

// -----------------------------------------------------------------------
// شناساییِ «زبان» از رویِ خودِ id — دو قالبِ رایج داریم:
//   ۱) `نوع:شناسه:کدزبان` (مثلاً word:12:en) — زبان آخرین بخشه.
//   ۲) `نوع:کدزبان::متن` (مثلاً conv:en::Your tires are fine...، یا
//      story:fa::سلام) — اینجا زبان بلافاصله بعدِ اولین «:» میاد، نه
//      انتهای id (چون بعدش خودِ متن با «::» شروع می‌شه). توی تبِ مکالماتِ
//      روزمره، برای هر خط، «متن» همیشه همون جمله‌ی انگلیسیِ اصلیه (چه برایِ
//      خودِ انگلیسی، چه برایِ هر ترجمه) — پس با این الگو، شناسه‌ی پایه‌ی
//      همه‌ی زبان‌های یه خط یکی از آب در میاد و کنارِ هم جمع می‌شن.
// اگه هیچ‌کدوم مچ نشه، کلِ id به‌عنوانِ شناسه‌ی پایه در نظر گرفته می‌شه و
// زبانش نامشخص (null) می‌مونه.
const LANG_SUFFIX_RE = /^[a-z]{2,3}(-[a-zA-Z]{2,4})?$/;
const LANG_DOUBLE_COLON_RE = /^([^:]+):([a-z]{2,3}(?:-[a-zA-Z]{2,4})?)::([\s\S]*)$/;
export function splitNeuralId(id) {
  if (!id) return { base: id, lang: null };
  const m = id.match(LANG_DOUBLE_COLON_RE);
  if (m) {
    const [, type, lang, rest] = m;
    return { base: `${type}::${rest}`, lang };
  }
  const idx = id.lastIndexOf(":");
  if (idx === -1) return { base: id, lang: null };
  const lang = id.slice(idx + 1);
  if (!LANG_SUFFIX_RE.test(lang)) return { base: id, lang: null };
  return { base: id.slice(0, idx), lang };
}

/** همه‌ی رویدادهای مربوط به یه آیتم رو — از رویِ همه‌ی زبان‌هاش —
 *  یکجا برمی‌گردونه؛ هر رویداد با {t, s, lang} مشخص می‌شه. برای تقویمی
 *  که باید «به‌طور لحظه‌ای» زبان‌های مختلفِ یه آیتم رو کنارِ هم نشون بده.
 */
export function getNeuralEventsGrouped(id) {
  if (!id) return [];
  const { base } = splitNeuralId(id);
  const store = loadStore();
  const out = [];
  Object.keys(store).forEach((key) => {
    const parts = splitNeuralId(key);
    if (parts.base !== base) return;
    const lang = parts.lang || "?";
    (store[key] || []).forEach((e) => out.push({ t: e.t, s: e.s, lang }));
  });
  return out;
}

export function clearNeuralPath(id) {
  if (!id) return;
  const store = loadStore();
  const ledger = loadLedger();
  let changed = false;
  if (store[id]) {
    delete store[id];
    changed = true;
  }
  if (ledger[id]) {
    delete ledger[id];
    changed = true;
  }
  if (changed) {
    try {
      window.localStorage.setItem(STORE_KEY, JSON.stringify(cache));
    } catch {}
    try {
      window.localStorage.setItem(LEDGER_KEY, JSON.stringify(ledgerCache));
    } catch {}
    listeners.forEach((fn) => {
      try {
        fn();
      } catch {}
    });
  }
}

// -----------------------------------------------------------------------
// «رشته‌های عصبی» — دفترچه‌ی جداگانه‌ای از رویدادهای بالا: هر آیتم یه
// {logs:{}, habitFormed:false} داره. هر بار کاربر دکمه‌ی «امروز انجام
// دادم» رو بزنه یه فیبرِ true اضافه می‌شه، هر بار «یک روز گذشت، انجام
// ندادم» رو بزنه یه فیبرِ false. «رشته‌های ساخته‌شده» = (تعداد true) −
// (تعداد false)، هیچ‌وقت منفی نمی‌شه. برخلافِ سیستمِ «بازی فراوانی»، اینجا
// (چون هر آیتم با هزاران آیتمِ دیگه رقابت می‌کنه) هیچ کاهشِ خودکاری برای
// روزهای بی‌تمرین نداریم — فقط با کلیکِ خودِ کاربر رشته اضافه/کم می‌شه.
function loadLedger() {
  if (ledgerCache) return ledgerCache;
  try {
    ledgerCache = JSON.parse(window.localStorage.getItem(LEDGER_KEY) || "{}");
  } catch {
    ledgerCache = {};
  }
  return ledgerCache;
}

function persistLedger() {
  try {
    window.localStorage.setItem(LEDGER_KEY, JSON.stringify(ledgerCache));
  } catch {}
  listeners.forEach((fn) => {
    try {
      fn();
    } catch {}
  });
}

function ensureLedgerEntry(id) {
  const store = loadLedger();
  if (!store[id] || typeof store[id] !== "object") store[id] = { logs: {}, habitFormed: false };
  if (!store[id].logs || typeof store[id].logs !== "object") store[id].logs = {};
  return store[id];
}

// کلید یکتا برای هر رشته — هر کلیک رشته‌ی جدای خودش رو می‌سازه
function fiberKey() {
  return "f" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
}

export function neuralFiberCount(logs) {
  let n = 0;
  Object.keys(logs || {}).forEach((k) => {
    if (logs[k] === true) n++;
    else if (logs[k] === false) n--;
  });
  return Math.max(0, n);
}

/** «امروز انجام دادم»: نامحدود، همیشه یه رشته‌ی تازه اضافه می‌کنه */
export function addNeuralFiber(id) {
  if (!id) return;
  const entry = ensureLedgerEntry(id);
  entry.logs[fiberKey()] = true;
  persistLedger();
}

/** «یک روز گذشت، انجام ندادم»: نامحدود، یه رشته کم می‌کنه (تا صفر) */
export function removeNeuralFiber(id) {
  if (!id) return;
  const entry = ensureLedgerEntry(id);
  entry.logs[fiberKey()] = false;
  persistLedger();
}

/** دکمه‌ی «همینه، این عادت جاافتاد» — یه قفلِ toggle‌شونده، نه یه‌طرفه */
export function toggleHabitFormed(id) {
  if (!id) return;
  const entry = ensureLedgerEntry(id);
  entry.habitFormed = !entry.habitFormed;
  persistLedger();
}

export function getNeuralLedger(id) {
  if (!id) return { logs: {}, habitFormed: false };
  return ensureLedgerEntry(id);
}

export function useNeuralLedger(id) {
  const [, force] = useState(0);
  useEffect(() => {
    const fn = () => force((n) => n + 1);
    listeners.add(fn);
    return () => listeners.delete(fn);
  }, []);
  return getNeuralLedger(id);
}

export function useNeuralEvents(id) {
  const [, force] = useState(0);
  useEffect(() => {
    const fn = () => force((n) => n + 1);
    listeners.add(fn);
    return () => listeners.delete(fn);
  }, []);
  return getNeuralEvents(id);
}

/** نسخه‌ی زنده‌ی getNeuralEventsGrouped — با هر تغییر (حتی یه تکرارِ
 *  آنی/لحظه‌ای)، بلافاصله دوباره محاسبه می‌شه، بدون نیاز به هیچ جمع‌زدنِ
 *  دستی از طرفِ کامپوننت‌ها. */
export function useNeuralEventsGrouped(id) {
  const [, force] = useState(0);
  useEffect(() => {
    const fn = () => force((n) => n + 1);
    listeners.add(fn);
    return () => listeners.delete(fn);
  }, []);
  return getNeuralEventsGrouped(id);
}

function dayKey(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function monthKey(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function yearKey(ts) {
  return String(new Date(ts).getFullYear());
}

function summarize(events) {
  const last = events.length ? Math.max(...events.map((e) => e.t)) : null;
  return { total: events.length, last };
}

function fmtRel(ts) {
  if (!ts) return "—";
  const now = new Date();
  const d = new Date(ts);
  if (d.toDateString() === now.toDateString()) return "امروز";
  const y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return "دیروز";
  try {
    return d.toLocaleDateString("fa-IR");
  } catch {
    return d.toLocaleDateString();
  }
}

const DEFAULT_C = {
  paper: "#FBF6E9",
  border: "#E7DEC1",
  soft: "#F5F1E2",
  ink: "#1E2A26",
  inkSoft: "#4B5551",
  gold: "#C99A2E",
  goldSoft: "#E3C77E",
  teal: "#1B4640",
};

// ---------------------------------------------------------------------------
// اتصال به تنظیمِ تقویمِ app.jsx — از همون localStorage می‌خونیم که خودِ
// اپ تنظیمات رو اونجا ذخیره می‌کنه. هم به رویدادِ storage (تغییر بین تب‌ها)
// گوش می‌دیم، هم به رویدادِ custom (تغییر تو همون تب).
// ---------------------------------------------------------------------------
const APP_PREFS_KEY = "phrasebook-app-prefs";
const APP_PREFS_CHANGED_EVENT = "phrasebook:appPrefsChanged";

function getCalendarSystem() {
  try {
    const raw = window.localStorage.getItem(APP_PREFS_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return ["jalali", "gregorian", "both"].includes(parsed.calendarSystem) ? parsed.calendarSystem : "jalali";
  } catch {
    return "jalali";
  }
}
function useCalendarSystem() {
  const [cs, setCs] = useState(getCalendarSystem);
  useEffect(() => {
    const refresh = () => setCs(getCalendarSystem());
    window.addEventListener("storage", refresh);
    window.addEventListener(APP_PREFS_CHANGED_EVENT, refresh);
    return () => {
      window.removeEventListener("storage", refresh);
      window.removeEventListener(APP_PREFS_CHANGED_EVENT, refresh);
    };
  }, []);
  return cs;
}

// ---------------------------------------------------------------------------
// تبدیلاتِ تاریخِ شمسی/میلادی — نسخه‌ی استاندارد
// ---------------------------------------------------------------------------
const PERSIAN_MONTHS_FULL = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
const EN_MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function gregorianToJalali(gy, gm, gd) {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy;
  if (gy > 1600) { jy = 979; gy -= 1600; } else { jy = 0; gy -= 621; }
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
  let jm, jd;
  if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
  else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
  return [jy, jm, jd];
}

function jalaliToGregorian(jy, jm, jd) {
  let gy = jy > 979 ? 1600 : 621;
  if (jy > 979) jy -= 979;
  let days = 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + 78 + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) { gy += 100 * Math.floor(--days / 36524); days %= 36524; if (days >= 365) days++; }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
  let gd = days + 1;
  const isLeap = (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0;
  const monthDays = [0, 31, isLeap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 1;
  while (gm <= 12 && gd > monthDays[gm]) { gd -= monthDays[gm]; gm++; }
  return [gy, gm, gd];
}

function isJalaliLeapYear(jy) {
  const [gy, gm, gd] = jalaliToGregorian(jy, 12, 30);
  const [ry, rm, rd] = gregorianToJalali(gy, gm, gd);
  return ry === jy && rm === 12 && rd === 30;
}

function pad2(n) { return String(n).padStart(2, "0"); }
function toEnDigits(s) { return String(s).replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))); }

function navBtnStyle(c) {
  return {
    width: 24,
    height: 24,
    borderRadius: 6,
    border: `1px solid ${c.border}`,
    background: "#fff",
    color: c.ink,
    fontSize: 13,
    cursor: "pointer",
  };
}

function DayGrid({ cursor, setCursor, byDay, c, calendarSystem, selectedDay, onSelectDay }) {
  const isGregorian = calendarSystem === "gregorian";
  const showSecondary = calendarSystem === "both";

  // ---------- حالتِ میلادی ----------
  if (isGregorian) {
    const gyear = cursor.getFullYear();
    const gmonth = cursor.getMonth();
    const daysInMonth = new Date(gyear, gmonth + 1, 0).getDate();
    const startCol = new Date(gyear, gmonth, 1).getDay(); // یکشنبه=۰
    const cells = [];
    for (let i = 0; i < startCol; i++) cells.push(null);
    for (let d = 1; d <= daysInMonth; d++) cells.push(d);
    const today = new Date();
    let recorded = 0;
    for (let d = 1; d <= daysInMonth; d++) {
      if ((byDay.get(`${gyear}-${pad2(gmonth + 1)}-${pad2(d)}`) || 0) > 0) recorded++;
    }
    return (
      <div dir="ltr">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
          <button onClick={() => setCursor(new Date(gyear, gmonth - 1, 1))} style={{ ...navBtnStyle(c), width: 30, height: 30, fontSize: 15 }}>‹</button>
          <span style={{ fontSize: 12.5, fontWeight: 800, color: c.ink }}>
            {["January","February","March","April","May","June","July","August","September","October","November","December"][gmonth]} {gyear}
          </span>
          <button onClick={() => setCursor(new Date(gyear, gmonth + 1, 1))} style={{ ...navBtnStyle(c), width: 30, height: 30, fontSize: 15 }}>›</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 3 }}>
          {["S","M","T","W","T","F","S"].map((d, i) => (
            <div key={i} style={{ textAlign: "center", fontSize: 10, color: c.inkSoft, fontWeight: 700 }}>{d}</div>
          ))}
          {cells.map((d, i) => {
            if (d === null) return <div key={i} />;
            const key = `${gyear}-${pad2(gmonth + 1)}-${pad2(d)}`;
            const n = byDay.get(key) || 0;
            const isToday = today.getFullYear() === gyear && today.getMonth() === gmonth && today.getDate() === d;
            const isSelected = key === selectedDay;
            return (
              <div
                key={i}
                onClick={() => onSelectDay && onSelectDay(key)}
                title={`${d} ${EN_MONTHS_SHORT[gmonth]} ${gyear}${n ? ` · ${n} تکرار` : " · ثبت نشده"}`}
                style={{
                  position: "relative", aspectRatio: "1", display: "flex",
                  alignItems: "center", justifyContent: "center", borderRadius: 7,
                  fontSize: 11, fontWeight: n ? 800 : 500,
                  background: n ? c.gold : "transparent",
                  color: n ? "#fff" : c.inkSoft,
                  border: isToday ? `1.5px solid ${c.teal}` : "1px solid transparent",
                  boxShadow: isSelected ? `0 0 0 2px ${c.teal}` : "none",
                  cursor: "pointer",
                }}
              >
                {d}
                {n > 0 && (
                  <span style={{ position: "absolute", top: 1, left: 2, fontSize: 7, fontWeight: 800, background: "#fff", color: c.gold, borderRadius: 5, padding: "0 3px", lineHeight: 1.3 }}>
                    {n}
                  </span>
                )}
              </div>
            );
          })}
        </div>
        {recorded === 0 && (
          <p style={{ fontSize: 10.5, color: c.inkSoft, textAlign: "center", marginTop: 8, fontStyle: "italic" }}>
            این ماه هیچ تمرینی ثبت نشده.
          </p>
        )}
        <button onClick={() => { const t = new Date(); setCursor(t); onSelectDay && onSelectDay(dayKey(t)); }} style={{ marginTop: 8, width: "100%", padding: "5px 0", borderRadius: 8, border: `1px solid ${c.border}`, background: c.soft, color: c.ink, fontSize: 10.5, fontWeight: 700, cursor: "pointer" }}>
          برو به امروز
        </button>
      </div>
    );
  }

  // ---------- حالتِ شمسی (یا هردو) ----------
  const [jy, jm] = gregorianToJalali(cursor.getFullYear(), cursor.getMonth() + 1, cursor.getDate());
  const daysInMonth = jm <= 6 ? 31 : jm <= 11 ? 30 : (isJalaliLeapYear(jy) ? 30 : 29);
  const [gy0, gm0, gd0] = jalaliToGregorian(jy, jm, 1);
  const firstDate = new Date(gy0, gm0 - 1, gd0);
  const startCol = (firstDate.getDay() + 1) % 7; // شنبه=۰
  const cells = [];
  for (let i = 0; i < startCol; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  const [gyEnd, gmEnd, gdEnd] = jalaliToGregorian(jy, jm, daysInMonth);
  const today = new Date();
  const [tjy, tjm, tjd] = gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());

  let recorded = 0;
  for (let d = 1; d <= daysInMonth; d++) {
    const [gy, gm, gd] = jalaliToGregorian(jy, jm, d);
    if ((byDay.get(`${gy}-${pad2(gm)}-${pad2(gd)}`) || 0) > 0) recorded++;
  }

  const goMonth = (delta) => {
    let ny = jy, nm = jm + delta;
    while (nm > 12) { nm -= 12; ny += 1; }
    while (nm < 1) { nm += 12; ny -= 1; }
    const [gy, gm, gd] = jalaliToGregorian(ny, nm, 1);
    setCursor(new Date(gy, gm - 1, gd));
  };

  return (
    <div dir="ltr">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6, gap: 4 }}>
        <button onClick={() => goMonth(-1)} style={{ ...navBtnStyle(c), width: 30, height: 30, fontSize: 15 }}>‹</button>
        <div style={{ textAlign: "center", flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 800, color: c.ink }}>
            {PERSIAN_MONTHS_FULL[jm - 1]} {jy}
          </div>
          {showSecondary && (
            <div style={{ fontSize: 9.5, color: c.inkSoft }}>
              {`${gd0} ${EN_MONTHS_SHORT[gm0 - 1]} – ${gdEnd} ${EN_MONTHS_SHORT[gmEnd - 1]} ${gy0}`}
            </div>
          )}
        </div>
        <button onClick={() => goMonth(1)} style={{ ...navBtnStyle(c), width: 30, height: 30, fontSize: 15 }}>›</button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 3 }}>
        {["ش","ی","د","س","چ","پ","ج"].map((d, i) => (
          <div key={i} style={{ textAlign: "center", fontSize: 10, color: c.inkSoft, fontWeight: 700 }}>{d}</div>
        ))}
        {cells.map((d, i) => {
          if (d === null) return <div key={i} />;
          const [gy, gm, gd] = jalaliToGregorian(jy, jm, d);
          const key = `${gy}-${pad2(gm)}-${pad2(gd)}`;
          const n = byDay.get(key) || 0;
          const isToday = jy === tjy && jm === tjm && d === tjd;
          const isSelected = key === selectedDay;
          return (
            <div
              key={i}
              onClick={() => onSelectDay && onSelectDay(key)}
              title={`${d} ${PERSIAN_MONTHS_FULL[jm - 1]} ${jy}${showSecondary ? ` — ${gd} ${EN_MONTHS_SHORT[gm - 1]}` : ""}${n ? ` · ${n} تکرار` : " · ثبت نشده"}`}
              style={{
                position: "relative", aspectRatio: "1", display: "flex",
                flexDirection: "column", alignItems: "center", justifyContent: "center",
                borderRadius: 7, fontSize: 10.5, fontWeight: n ? 800 : 500,
                background: n ? c.gold : "transparent",
                color: n ? "#fff" : c.inkSoft,
                border: isToday ? `1.5px solid ${c.teal}` : "1px solid transparent",
                boxShadow: isSelected ? `0 0 0 2px ${c.teal}` : "none",
                cursor: "pointer",
                padding: "1px 0",
              }}
            >
              <span style={{ fontSize: 11, lineHeight: 1.1 }}>{d}</span>
              {showSecondary && (
                <span style={{ fontSize: 7.5, lineHeight: 1, opacity: 0.7, marginTop: 1 }}>{gd}</span>
              )}
              {n > 0 && (
                <span style={{ position: "absolute", top: 1, left: 2, fontSize: 7, fontWeight: 800, background: "#fff", color: c.gold, borderRadius: 5, padding: "0 3px", lineHeight: 1.3 }}>
                  {n}
                </span>
              )}
            </div>
          );
        })}
      </div>
      {recorded === 0 && (
        <p style={{ fontSize: 10.5, color: c.inkSoft, textAlign: "center", marginTop: 8, fontStyle: "italic" }}>
          این ماه هیچ تمرینی ثبت نشده.
        </p>
      )}
      <button onClick={() => { const t = new Date(); setCursor(t); onSelectDay && onSelectDay(dayKey(t)); }} style={{ marginTop: 8, width: "100%", padding: "5px 0", borderRadius: 8, border: `1px solid ${c.border}`, background: c.soft, color: c.ink, fontSize: 10.5, fontWeight: 700, cursor: "pointer" }}>
        برو به امروز
      </button>
    </div>
  );
}

const FA_MONTHS_SHORT = ["ژان", "فور", "مار", "آور", "می", "ژون", "جول", "اوت", "سپت", "اکت", "نوا", "دسا"];

function MonthGrid({ cursor, setCursor, byMonth, c, calendarSystem }) {
  const isGregorian = calendarSystem === "gregorian";
  const showSecondary = calendarSystem === "both";

  // ---------- میلادی ----------
  if (isGregorian) {
    const gyear = cursor.getFullYear();
    const cells = [];
    for (let m = 0; m < 12; m++) {
      let count = 0;
      const daysInMonth = new Date(gyear, m + 1, 0).getDate();
      for (let d = 1; d <= daysInMonth; d++) count += byMonth.get(`${gyear}-${pad2(m + 1)}`) || 0;
      cells.push({ m, count });
    }
    return (
      <div dir="ltr">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
          <button onClick={() => setCursor(new Date(gyear - 1, 0, 1))} style={{ ...navBtnStyle(c), width: 30, height: 30, fontSize: 15 }}>‹</button>
          <span style={{ fontSize: 12.5, fontWeight: 800, color: c.ink }}>{gyear}</span>
          <button onClick={() => setCursor(new Date(gyear + 1, 0, 1))} style={{ ...navBtnStyle(c), width: 30, height: 30, fontSize: 15 }}>›</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 5 }}>
          {cells.map((cell) => (
            <div
              key={cell.m}
              onClick={() => setCursor(new Date(gyear, cell.m, 1))}
              style={{ padding: "6px 3px", borderRadius: 8, textAlign: "center", background: cell.count ? c.goldSoft : c.soft, border: `1px solid ${cell.count ? c.gold : c.border}`, cursor: "pointer" }}
            >
              <div style={{ fontSize: 10.5, color: c.ink, fontWeight: 700 }}>{EN_MONTHS_SHORT[cell.m]}</div>
              <div style={{ fontSize: 12, color: cell.count ? c.gold : c.inkSoft, fontWeight: 800 }}>{cell.count || "—"}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ---------- شمسی / هر دو ----------
  const [jy] = gregorianToJalali(cursor.getFullYear(), cursor.getMonth() + 1, cursor.getDate());
  const cells = [];
  for (let m = 1; m <= 12; m++) {
    const daysInMonth = m <= 6 ? 31 : m <= 11 ? 30 : (isJalaliLeapYear(jy) ? 30 : 29);
    const [gyS, gmS, gdS] = jalaliToGregorian(jy, m, 1);
    const [gyE, gmE, gdE] = jalaliToGregorian(jy, m, daysInMonth);
    let count = 0;
    for (let d = 1; d <= daysInMonth; d++) {
      const [gy, gm] = jalaliToGregorian(jy, m, d);
      count += byMonth.get(`${gy}-${pad2(gm)}`) || 0;
    }
    cells.push({ m, count, gyS, gmS, gdS, gmE, gdE });
  }
  const goYear = (delta) => {
    const [gy, gm, gd] = jalaliToGregorian(jy + delta, 1, 1);
    setCursor(new Date(gy, gm - 1, gd));
  };
  return (
    <div dir="ltr">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
        <button onClick={() => goYear(-1)} style={{ ...navBtnStyle(c), width: 30, height: 30, fontSize: 15 }}>‹</button>
        <span style={{ fontSize: 12.5, fontWeight: 800, color: c.ink }}>{jy}</span>
        <button onClick={() => goYear(1)} style={{ ...navBtnStyle(c), width: 30, height: 30, fontSize: 15 }}>›</button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 5 }}>
        {cells.map((cell) => (
          <div
            key={cell.m}
            onClick={() => {
              const [gy, gm, gd] = jalaliToGregorian(jy, cell.m, 1);
              setCursor(new Date(gy, gm - 1, gd));
            }}
            style={{ padding: "6px 3px", borderRadius: 8, textAlign: "center", background: cell.count ? c.goldSoft : c.soft, border: `1px solid ${cell.count ? c.gold : c.border}`, cursor: "pointer" }}
          >
            <div style={{ fontSize: 10.5, color: c.ink, fontWeight: 700 }}>{PERSIAN_MONTHS_FULL[cell.m - 1]}</div>
            {showSecondary && (
              <div style={{ fontSize: 8.5, color: c.inkSoft }}>{EN_MONTHS_SHORT[cell.gmS - 1]}–{EN_MONTHS_SHORT[cell.gmE - 1]}</div>
            )}
            <div style={{ fontSize: 12, color: cell.count ? c.gold : c.inkSoft, fontWeight: 800 }}>{cell.count || "—"}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function YearList({ byYear, c, calendarSystem }) {
  const years = Array.from(byYear.keys()).sort();
  if (years.length === 0)
    return <p style={{ fontSize: 12, color: c.inkSoft, textAlign: "center", padding: "6px 0" }}>هنوز داده‌ای برای نمای سالانه نیست.</p>;
  const isGregorian = calendarSystem === "gregorian";
  const showSecondary = calendarSystem === "both";
  return (
    <div dir="ltr" style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {years.map((gy) => {
        const [jy] = gregorianToJalali(Number(gy), 1, 1);
        const primary = isGregorian ? gy : jy;
        const secondaryLabel = isGregorian
          ? (showSecondary ? `(${jy} شمسی)` : "")
          : (showSecondary ? `(${gy} میلادی)` : "");
        return (
          <div key={gy} style={{ display: "flex", justifyContent: "space-between", padding: "7px 10px", borderRadius: 8, background: c.soft, border: `1px solid ${c.border}` }}>
            <span style={{ fontSize: 12.5, fontWeight: 700, color: c.ink }}>
              {primary} {secondaryLabel && <span style={{ fontSize: 10, color: c.inkSoft }}>{secondaryLabel}</span>}
            </span>
            <span style={{ fontSize: 12.5, fontWeight: 800, color: c.gold }}>{byYear.get(gy)} تکرار</span>
          </div>
        );
      })}
    </div>
  );
}

// فرمتِ عنوانِ روزِ انتخاب‌شده، مطابقِ همون تنظیمِ تقویمِ کاربر (شمسی/میلادی/هردو)
function formatDayHeader(key, calendarSystem) {
  const [gy, gm, gd] = key.split("-").map(Number);
  const gregorianStr = `${gd} ${EN_MONTHS_SHORT[gm - 1]} ${gy}`;
  const [jy, jm, jd] = gregorianToJalali(gy, gm, gd);
  const jalaliStr = `${jd} ${PERSIAN_MONTHS_FULL[jm - 1]} ${jy}`;
  if (calendarSystem === "gregorian") return gregorianStr;
  if (calendarSystem === "both") return `${jalaliStr} (${gregorianStr})`;
  return jalaliStr;
}

// جزئیاتِ روزِ انتخاب‌شده: طبقِ درخواستِ کاربر، دیگه ساعتِ دقیقِ هر
// تکرار نشون داده نمی‌شه — فقط توی همین تقویم، برای اون روز، تعدادِ
// تکرارِ هر زبان جدا جدا نشون داده می‌شه (مثلاً en: ۳ بار، es: ۶ بار).
// چون events از getNeuralEventsGrouped میاد، خودِ زبان‌ها (نسخه‌ی اصلی +
// همه‌ی ترجمه‌ها) به‌طور لحظه‌ای و بدون نیاز به جمع‌زدنِ دستی به‌هم
// وصل‌ان — با هر تکرارِ تازه، لیست بلافاصله به‌روز می‌شه.
function DayDetailsPanel({ dayKeyStr, events, c, calendarSystem }) {
  const dayEvents = useMemo(() => {
    return (events || []).filter((e) => dayKey(e.t) === dayKeyStr);
  }, [events, dayKeyStr]);

  const byLang = useMemo(() => {
    const m = new Map();
    dayEvents.forEach((e) => {
      const lang = e.lang || "?";
      m.set(lang, (m.get(lang) || 0) + 1);
    });
    return Array.from(m.entries()).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  }, [dayEvents]);

  if (!dayKeyStr) return null;
  const header = formatDayHeader(dayKeyStr, calendarSystem);

  return (
    <div style={{ marginTop: 10, paddingTop: 8, borderTop: `1px dashed ${c.border}` }}>
      <div style={{ fontSize: 11, fontWeight: 800, color: c.ink, marginBottom: 6, textAlign: "center" }}>
        {header}
        {dayEvents.length > 0 && <span style={{ color: c.gold }}> · {dayEvents.length} تکرار</span>}
      </div>
      {dayEvents.length === 0 ? (
        <p style={{ fontSize: 10.5, color: c.inkSoft, textAlign: "center", fontStyle: "italic" }}>
          در این روز تمرینی ثبت نشده.
        </p>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 4, maxHeight: 150, overflowY: "auto" }}>
          {byLang.map(([lang, count]) => (
            <div
              key={lang}
              style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 10.5, padding: "5px 9px", borderRadius: 7, background: c.soft }}
            >
              <span style={{ color: c.ink, fontWeight: 800 }}>{lang}</span>
              <span style={{ color: c.inkSoft }}>{count} بار</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 🧭 تقویمِ دوره‌ای — همون منطقِ تقویمِ «دوره‌ی N روزه / ماه اول، ماه دوم، ...»
// که توی Maghz هست: یه شبکه‌ی ۱۵ ستونه از روزهای دوره، که هر ۳۰ روز یه
// سرتیتر «ماه X» (با بازه‌ی تاریخ) داره. روزی که توش حداقل یه تکرار ثبت
// شده پر می‌شه. دوره‌ی جاری همیشه توی {days, startDate} می‌مونه؛ وقتی تموم
// شد و کاربر «دوره‌ی بعدی» رو زد، همون به past اضافه می‌شه و هیچ‌وقت پاک
// نمی‌شه (دوره‌ی اول، دوم، ...). برای هر آیتم جدا ذخیره می‌شه (مشترک بینِ
// همه‌ی زبان‌های همون آیتم، مثلِ خودِ تقویم).
// ---------------------------------------------------------------------------
const PERIOD_KEY = "phrasebook-neural-period-v1";
const PERIOD_DEFAULT_DAYS = 28;
const PERIOD_MAX_DAYS = 365;
const PERIOD_BLOCK_DAYS = 30;
const PERIOD_MONTH_ORD = ["اول", "دوم", "سوم", "چهارم", "پنجم", "ششم", "هفتم", "هشتم", "نهم", "دهم", "یازدهم", "دوازدهم", "سیزدهم"];

function parseDayKey(k) {
  const [y, m, d] = String(k).split("-").map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  return isNaN(dt.getTime()) ? new Date(new Date().setHours(0, 0, 0, 0)) : dt;
}

function loadPeriods() {
  try {
    const parsed = JSON.parse(window.localStorage.getItem(PERIOD_KEY) || "{}");
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function saveNeuralPeriod(id, period) {
  if (!id) return;
  const all = loadPeriods();
  all[splitNeuralId(id).base] = period;
  try {
    window.localStorage.setItem(PERIOD_KEY, JSON.stringify(all));
  } catch {}
}

// اولین باری که تقویمِ یه آیتم باز می‌شه، دوره‌ش از «امروز» شروع می‌شه.
function loadNeuralPeriod(id) {
  const saved = (id && loadPeriods()[splitNeuralId(id).base]) || {};
  const n = parseInt(saved.days, 10);
  const past = Array.isArray(saved.past)
    ? saved.past.filter((p) => p && typeof p.startDate === "string" && parseInt(p.days, 10) >= 1)
    : [];
  const period = {
    days: n >= 1 ? Math.min(n, PERIOD_MAX_DAYS) : PERIOD_DEFAULT_DAYS,
    startDate: typeof saved.startDate === "string" && saved.startDate ? saved.startDate : dayKey(Date.now()),
    past,
  };
  if (JSON.stringify(period) !== JSON.stringify(saved)) saveNeuralPeriod(id, period);
  return period;
}

function NeuralCalendar({ id, events, c }) {
  const calendarSystem = useCalendarSystem();
  const [period, setPeriod] = useState(() => loadNeuralPeriod(id));
  const [selectedDay, setSelectedDay] = useState(null);
  const [openPast, setOpenPast] = useState({});
  const faNum = (n) => Number(n).toLocaleString("fa-IR");
  const ord = (i) => PERIOD_MONTH_ORD[i] || faNum(i + 1);

  const byDay = useMemo(() => {
    const m = new Map();
    events.forEach((e) => m.set(dayKey(e.t), (m.get(dayKey(e.t)) || 0) + 1));
    return m;
  }, [events]);

  const total = period.days;
  const past = period.past || [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayKey = dayKey(Date.now());

  // تاریخِ سرتیترِ هر «ماه»: میلادی فقط وقتی تنظیمِ تقویم «میلادی» باشه؛ در غیر این صورت شمسی
  const fmtDate = (date) => {
    if (calendarSystem === "gregorian") return `${date.getDate()} ${EN_MONTHS_SHORT[date.getMonth()]}`;
    const [, jm, jd] = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
    return `${faNum(jd)} ${PERSIAN_MONTHS_FULL[jm - 1]}`;
  };

  // یه دوره (روزِ شروع + تعدادِ روز) → شبکه‌ی «ماه اول، ماه دوم، ...»؛
  // هم برای دوره‌ی جاری، هم برای دوره‌های قبلی.
  const buildGrid = (startKey, days) => {
    const start = parseDayKey(startKey);
    const cells = [];
    let doneCount = 0;
    let hasSelected = false;
    for (let d = 0; d < days; d++) {
      const date = new Date(start.getFullYear(), start.getMonth(), start.getDate() + d);
      const key = dayKey(date);
      if (d % PERIOD_BLOCK_DAYS === 0) {
        const endDate = new Date(start.getFullYear(), start.getMonth(), start.getDate() + Math.min(d + PERIOD_BLOCK_DAYS - 1, days - 1));
        const mIdx = d / PERIOD_BLOCK_DAYS;
        cells.push(
          <div
            key={`${startKey}-m${d}`}
            style={{ gridColumn: "1 / -1", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 10.5, color: c.inkSoft, padding: d === 0 ? "0 2px 2px" : "6px 2px 2px" }}
          >
            <b style={{ fontSize: 11, color: c.ink }}>ماه {ord(mIdx)}</b>
            <span>{fmtDate(date)} تا {fmtDate(endDate)}</span>
          </div>
        );
      }
      const n = byDay.get(key) || 0;
      const done = n > 0;
      if (done) doneCount++;
      const isToday = key === todayKey;
      const isFuture = date > today;
      const isSelected = key === selectedDay;
      if (isSelected) hasSelected = true;
      const isMonthEnd = d % PERIOD_BLOCK_DAYS === PERIOD_BLOCK_DAYS - 1 || d === days - 1;
      const shadows = [];
      if (!done) shadows.push(`inset 0 0 0 1px ${c.border}`);
      if (isMonthEnd) shadows.push(`inset 0 -3px 0 ${c.teal}`);
      cells.push(
        <div
          key={`${startKey}-${key}`}
          onClick={() => { if (!isFuture) setSelectedDay((cur) => (cur === key ? null : key)); }}
          title={`${formatDayHeader(key, calendarSystem)}${n ? ` · ${n} تکرار` : " · ثبت نشده"}`}
          style={{
            aspectRatio: "1", minWidth: 0, borderRadius: 4,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 10, fontWeight: 800, lineHeight: 1, color: "#fff",
            background: done ? c.gold : c.soft,
            boxShadow: shadows.length ? shadows.join(", ") : "none",
            outline: isSelected ? `2px solid ${c.ink}` : isToday ? `1.5px solid ${c.teal}` : "none",
            outlineOffset: isSelected ? 1 : 0,
            opacity: isFuture ? 0.3 : 1,
            cursor: isFuture ? "default" : "pointer",
          }}
        >
          {done ? "✓" : ""}
        </div>
      );
    }
    return { cells, doneCount, hasSelected };
  };

  const cur = buildGrid(period.startDate, total);
  const gridStyle = { display: "grid", gridTemplateColumns: "repeat(15, minmax(0, 1fr))", gap: 3 };

  const start = parseDayKey(period.startDate);
  const passed = Math.round((today - start) / 86400000) + 1;
  const dayNum = Math.max(1, Math.min(total, passed));
  const endOfPeriod = new Date(start.getFullYear(), start.getMonth(), start.getDate() + total);
  const finished = today >= endOfPeriod;

  const askDays = (question) => {
    const input = window.prompt(question, String(total));
    if (input === null) return 0;
    const norm = String(input).replace(/[۰-۹٠-٩]/g, (ch) => {
      const i = "۰۱۲۳۴۵۶۷۸۹".indexOf(ch);
      return i > -1 ? i : "٠١٢٣٤٥٦٧٨٩".indexOf(ch);
    });
    const n = parseInt(norm, 10);
    if (!n || n < 1 || n > PERIOD_MAX_DAYS) {
      window.alert(`یه عدد بین ۱ تا ${faNum(PERIOD_MAX_DAYS)} وارد کن`);
      return 0;
    }
    return n;
  };

  // «⚙️ روزهای دوره»: فقط طولِ همین دوره‌ی جاری رو عوض می‌کنه
  const changeDays = () => {
    const n = askDays(`دوره‌ی ${ord(past.length)} چند روزه باشه؟ (۱ تا ${faNum(PERIOD_MAX_DAYS)})`);
    if (!n) return;
    const next = { ...period, days: n };
    saveNeuralPeriod(id, next);
    setPeriod(next);
  };

  // «▶️ شروع دوره‌ی بعدی»: دوره‌ی تمام‌شده به past می‌ره (پاک نمی‌شه) و دوره‌ی تازه از امروز شروع می‌شه
  const startNextPeriod = () => {
    const n = askDays(`دوره‌ی ${ord(past.length + 1)} چند روزه باشه؟ (۱ تا ${faNum(PERIOD_MAX_DAYS)})`);
    if (!n) return;
    const next = { days: n, startDate: todayKey, past: [...past, { days: total, startDate: period.startDate }] };
    saveNeuralPeriod(id, next);
    setPeriod(next);
    setSelectedDay(null);
  };

  const detailsPanel = <DayDetailsPanel dayKeyStr={selectedDay} events={events} c={c} calendarSystem={calendarSystem} />;

  return (
    <div dir="rtl" style={{ marginTop: 10, borderTop: `1px dashed ${c.border}`, paddingTop: 10 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, fontSize: 12, fontWeight: 800, color: c.ink, marginBottom: 8 }}>
        <span>🧭 دوره‌ی {past.length ? `${ord(past.length)} — ` : ""}{faNum(total)} روزه</span>
        <span style={{ fontSize: 10.5, fontWeight: 700, color: c.inkSoft }}>روز {faNum(dayNum)} / {faNum(total)}</span>
      </div>
      <div style={gridStyle}>{cur.cells}</div>
      {cur.hasSelected && detailsPanel}
      {finished ? (
        <>
          <div style={{ marginTop: 8, padding: "9px 11px", borderRadius: 10, background: c.soft, border: `1px solid ${c.goldSoft}`, fontSize: 11.5, fontWeight: 700, lineHeight: 1.8, color: c.ink }}>
            🎉🥳 دوره‌ی {ord(past.length)} رو تموم کردی! {faNum(Math.min(cur.doneCount, total))} روز از {faNum(total)} روز تمرین کردی.
            <br />
            برای ادامه دوره‌ی بعدی رو شروع کن — دوره‌های قبلی همین‌جا می‌مونن.
          </div>
          <button
            onClick={startNextPeriod}
            style={{ marginTop: 8, width: "100%", padding: "8px 0", borderRadius: 8, border: `1px solid ${c.gold}`, background: c.goldSoft, color: c.ink, fontSize: 11.5, fontWeight: 700, cursor: "pointer" }}
          >
            ▶️ شروع دوره‌ی {ord(past.length + 1)}
          </button>
        </>
      ) : (
        <button
          onClick={changeDays}
          style={{ marginTop: 8, width: "100%", padding: "8px 0", borderRadius: 8, border: `1px solid ${c.border}`, background: c.soft, color: c.ink, fontSize: 11.5, fontWeight: 700, cursor: "pointer" }}
        >
          ⚙️ روزهای دوره (الان {faNum(total)} روزه)
        </button>
      )}
      {past.length > 0 && (
        <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 6 }}>
          {past
            .map((p, i) => ({ p, i }))
            .reverse()
            .map(({ p, i }) => {
              const g = buildGrid(p.startDate, p.days);
              const open = !!openPast[i];
              return (
                <div key={`${p.startDate}-${i}`} style={{ padding: "8px 10px", borderRadius: 10, border: `1px solid ${c.border}`, background: c.soft }}>
                  <div
                    onClick={() => setOpenPast((o) => ({ ...o, [i]: !o[i] }))}
                    style={{ display: "flex", justifyContent: "space-between", gap: 8, fontSize: 11.5, fontWeight: 800, color: c.ink, cursor: "pointer" }}
                  >
                    <span>✅ دوره‌ی {ord(i)} — {faNum(p.days)} روزه</span>
                    <span style={{ color: c.inkSoft }}>{faNum(g.doneCount)} / {faNum(p.days)} {open ? "▲" : "▼"}</span>
                  </div>
                  {open && (
                    <>
                      <div style={{ ...gridStyle, marginTop: 8 }}>{g.cells}</div>
                      {g.hasSelected && detailsPanel}
                    </>
                  )}
                </div>
              );
            })}
        </div>
      )}
    </div>
  );
}

// 🧬 خودِ «رشته‌های عصبی» — خط‌هایی که دو نرون (دایره‌ی یادگیری و دایره‌ی
// تثبیت) رو به‌هم وصل می‌کنن. برخلافِ نسخه‌ی قبلی (یه خطِ تکی که فقط
// ضخیم‌تر می‌شد)، الان هر «رشته» (یعنی هر روزِ متفاوتی که توش تمرین ثبت
// شده) یه خطِ نازکِ جداگانه‌ست — دقیقاً مثلِ یه کابلِ بافته‌شده از چندین
// رشته‌ی باریک که هرکدوم کنارِ هم (نه روی هم) جمع می‌شن، شکلِ عدسی‌مانندِ
// وسطش با هر رشته‌ی تازه یه‌کم بازتر می‌شه. با هر ثبتِ تازه («امروز انجام
// دادم») یه رشته‌ی تازه اضافه می‌شه و یه پالسِ نورانی رویِ همون رشته‌ی
// تازه می‌ره؛ با حذفِ یه رشته («یک روز گذشت، انجام ندادم») هم یه پالسِ
// محوشونده‌ی قرمزِکم‌رنگ رویِ آخرین رشته می‌ره تا حسِ «کم‌شدن» منتقل بشه.
const CIRCLE_SIZE = 34;
// قبلاً روی ۸۰ تا قفل بود و رشته‌های بیشتر اصلاً رندر نمی‌شدن (رشته‌ی صدم و
// دویستم و پونصدم هیچ فرقی با رشته‌ی هشتادم نداشت). حالا خودِ کاربر تا
// ۵۰۰ رشته رو واقعاً می‌بینه.
const MAX_RENDERED_FIBERS = 500;

// هش سادهٔ قطعی (نه Math.random) — برای هر ایندکسِ رشته همیشه همون عددِ
// «تصادفی» رو می‌ده، پس بین رندرها نمی‌پره و جای رشته‌ها ثابت می‌مونه.
function seededJitter(seed) {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x); // بین ۰ و ۱
}
function NeuralFibers({ fiberCount, habitFormed, c }) {
  const prevCountRef = useRef(fiberCount);
  const [pulse, setPulse] = useState(null); // { key, kind: "add" | "remove" } | null

  useEffect(() => {
    if (fiberCount > prevCountRef.current) setPulse({ key: Date.now(), kind: "add" });
    else if (fiberCount < prevCountRef.current) setPulse({ key: Date.now(), kind: "remove" });
    prevCountRef.current = fiberCount;
  }, [fiberCount]);

  // مثلِ نورونِ «عادت»: وقتی رشته‌ها به سقف می‌رسن یا عادت قفل شده، رنگِ
  // رشته‌ها هم طلایی می‌شه؛ قبلش رنگِ خنثی‌تر (teal).
  const strong = habitFormed || fiberCount >= NEURAL_FIBER_CAP;
  const strandColor = strong ? c.gold : c.teal;

  if (fiberCount <= 0) return null;

  const n = Math.min(fiberCount, MAX_RENDERED_FIBERS);
  // پهنایِ بازشدنِ عدسی: رشدش با ریشه‌ی تعداد کنده می‌شه (نه خطی)، وگرنه با
  // چند صد رشته از کادر می‌زنه بیرون؛ با sqrt هم برای ۱۰ تا هم برای ۵۰۰ تا
  // فرق قابلِ‌دیدن داره.
  const spread = Math.min(34, 8 + Math.sqrt(n) * 1.2);
  // رشته‌ها دیگه هر دوتا سرشون رو دقیقاً روی همون یه پیکسل نمی‌ذارن — یه
  // کمی جابه‌جاییِ ثابت (نه رندوم واقعی) روی محیطِ نورون می‌گیرن تا وقتی
  // تعداد زیاد شد، سرها هم مثلِ یه دسته‌ی واقعی از رشته باز شن، نه یه نقطه‌ی
  // تیره‌ی توپر.
  const endpointSpread = Math.min(9, 2 + Math.sqrt(n) * 0.35);
  // هرچی رشته بیشتر باشه، هر تکِ رشته کم‌رنگ‌تر و نازک‌تر می‌شه — این باعث
  // می‌شه دسته‌ی رشته‌ها به‌جای یه لکه‌ی توپرِ تیره، مثلِ یه بافتِ ظریف دیده
  // بشه، حتی وقتی ۵۰۰ تا روی هم‌اند.
  const baseOpacity = Math.max(0.15, 0.6 - n * 0.0008);
  const baseWidth = n > 200 ? 0.2 : n > 80 ? 0.3 : 0.4;
  const paths = [];
  for (let i = 0; i < n; i++) {
    const t = n === 1 ? 0.5 : i / (n - 1);
    const bow = -spread / 2 + t * spread; // از بالا به پایینِ عدسی پخش می‌شن
    const startJitter = (seededJitter(i * 2 + 1) - 0.5) * endpointSpread;
    const endJitter = (seededJitter(i * 2 + 2) - 0.5) * endpointSpread;
    const isNewest = i === n - 1;
    paths.push(
      <path
        key={i}
        d={`M 14 ${20 + startJitter} Q 50 ${20 + bow} 86 ${20 + endJitter}`}
        fill="none"
        stroke={strandColor}
        strokeWidth={isNewest && pulse && pulse.kind === "add" ? baseWidth + 0.2 : baseWidth}
        strokeLinecap="round"
        opacity={isNewest ? 0.95 : baseOpacity}
      />
    );
  }

  return (
    <svg
      viewBox="0 0 100 40"
      preserveAspectRatio="none"
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", overflow: "visible", pointerEvents: "none" }}
    >
      {paths}
      {pulse && pulse.kind === "remove" && (
        <path
          key={`pulse-${pulse.key}`}
          d="M 14 20 Q 50 20 86 20"
          fill="none"
          stroke={c.rose || "#B4483F"}
          strokeWidth={6}
          strokeLinecap="round"
          style={{ animation: "neuralStrandPulse 0.9s ease-out" }}
        />
      )}
      <style>{`
        @keyframes neuralStrandPulse {
          0% { opacity: 0.6; }
          100% { opacity: 0; }
        }
      `}</style>
    </svg>
  );
}

function NeuralPathCard({ id, label, c, onClose, dragHandleProps }) {
  const events = useNeuralEvents(id);
  // تقویم جداگانه: تکرارهای همه‌ی زبان‌های همین آیتم (متنِ اصلی + هر
  // ترجمه) رو کنارِ هم می‌بینه، نه فقط زبانِ همین دکمه.
  const calendarEvents = useNeuralEventsGrouped(id);
  const s = useMemo(() => summarize(events), [events]);
  const ledger = useNeuralLedger(id);
  const fiberCount = neuralFiberCount(ledger.logs);
  const habitFormed = !!ledger.habitFormed;
  // آستانه‌های رنگِ نورونِ «عادت»: یه‌کم رنگ می‌گیره وقتی به یه سومِ سقف
  // رسیده، رنگِ کامل می‌گیره وقتی به سقف رسیده یا کاربر خودش قفلش کرده.
  const nodeMid = habitFormed || fiberCount >= Math.ceil(NEURAL_FIBER_CAP / 3);
  const nodeStrong = habitFormed || fiberCount >= NEURAL_FIBER_CAP;
  const [showCalendar, setShowCalendar] = useState(false);

  const doToday = () => {
    // «امروز انجام دادم» هم باید رویِ رشته‌های عصبی (fiberِ ledger) اثر بذاره
    // هم رویِ خودِ رویدادِ تکرار که تقویم/آمار ازش می‌خونن — تا وقتی کاربر
    // دستی ثبت می‌کنه، توی تقویم هم با ساعتش (منبع: «ثبتِ دستی») دیده بشه.
    recordNeuralRepeat(id, { source: "manual" });
    addNeuralFiber(id);
  };
  const doMissedDay = () => removeNeuralFiber(id);
  const doToggleHabit = () => toggleHabitFormed(id);

  let status;
  if (habitFormed) status = `این ${label} کاملاً جاافتاده — یک رشته‌ی عصبیِ واقعی 🎉`;
  else if (fiberCount <= 0) status = `هنوز مسیرِ عصبی‌ای برای این ${label} شکل نگرفته — همین امروز انجامش بده.`;
  else if (!nodeMid) status = `اولین رشته‌های عصبیِ این ${label} شکل گرفتن، ادامه بده.`;
  else if (!nodeStrong) status = `رشته‌های این ${label} دارن کنار هم جمع و ضخیم می‌شن.`;
  else status = `این ${label} یه مسیرِ عصبیِ محکم و جاافتاده شده — اگه حس می‌کنی واقعاً عادت شده، می‌تونی قفلش کنی.`;

  return (
    <div
      style={{
        background: c.paper,
        border: `1px solid ${c.border}`,
        borderRadius: 14,
        padding: 10,
        width: 232,
        maxWidth: "78vw",
        maxHeight: "80vh",
        overflowY: "auto",
        boxShadow: "0 8px 24px rgba(0,0,0,0.22)",
      }}
    >
      {/* دستگیره‌ی جابجایی — یه نوارِ کوچیکِ بالای کارت + کلِ ردیفِ عنوان،
          هر دو با انگشت/موس قابلِ کشیدنن (dragHandleProps از رویِ
          NeuralPathButton میاد). دکمه‌ی ✕ از این قانون مستثناست تا فشار
          دادنش با شروعِ درگ قاطی نشه. */}
      <div {...dragHandleProps} style={{ cursor: "grab", touchAction: "none", marginBottom: 6 }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 6 }}>
          <div style={{ width: 34, height: 4, borderRadius: 2, background: c.border }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ fontSize: 12, fontWeight: 800, color: c.ink, display: "flex", alignItems: "center", gap: 5 }}>
            <span>🧬</span>
            <span>مسیر عصبی این {label}</span>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label="بستن"
              style={{ width: 20, height: 20, flexShrink: 0, border: "none", background: "transparent", color: c.inkSoft, fontSize: 13, cursor: "pointer" }}
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* دو نرون («رفتار» و «عادت») در دو سرِ کادر + دسته‌ای از رشته‌های
          عصبیِ نازک که بینشون، مثلِ یه کابلِ بافته‌شده، وصل می‌شن. نرونِ
          «رفتار» همیشه خنثی می‌مونه؛ نرونِ «عادت» هرچی رشته‌ها بیشتر بشن
          پررنگ‌تر می‌شه. */}
      <div style={{ position: "relative", height: 62, marginBottom: 3 }}>
        <NeuralFibers fiberCount={fiberCount} habitFormed={habitFormed} c={c} />
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div
            style={{
              width: CIRCLE_SIZE,
              height: CIRCLE_SIZE,
              borderRadius: "50%",
              flexShrink: 0,
              background: c.soft,
              border: `2px solid ${c.border}`,
            }}
          />
          <div
            style={{
              width: CIRCLE_SIZE,
              height: CIRCLE_SIZE,
              borderRadius: "50%",
              flexShrink: 0,
              background: nodeStrong ? c.goldSoft : c.soft,
              border: `2px solid ${nodeMid ? c.gold : c.border}`,
            }}
          />
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
        <span style={{ fontSize: 10, fontWeight: 700, color: c.inkSoft, width: CIRCLE_SIZE, flexShrink: 0, textAlign: "center" }}>یادگیری</span>
        <span style={{ fontSize: 10, fontWeight: 700, color: nodeMid ? c.ink : c.inkSoft, width: CIRCLE_SIZE, flexShrink: 0, textAlign: "center" }}>تثبیت</span>
      </div>

      <div style={{ background: c.soft, borderRadius: 9, padding: "8px 6px", textAlign: "center", marginBottom: 8 }}>
        <div style={{ fontSize: 10, color: c.inkSoft, marginBottom: 5 }}>رشته‌های ساخته‌شده</div>
        <div style={{ fontSize: 15, fontWeight: 800, color: c.ink, marginBottom: 5 }}>{fiberCount}</div>
        {s.total > 0 && (
          <div style={{ fontSize: 9.5, color: c.inkSoft }}>
            {s.total} تکرار · آخرین تمرین: {fmtRel(s.last)}
          </div>
        )}
      </div>

      <p style={{ fontSize: 10.5, color: c.inkSoft, lineHeight: 1.85, marginBottom: 8, textAlign: "center" }}>{status}</p>

      <button
        onClick={doToday}
        style={{
          width: "100%",
          padding: "7px 0",
          borderRadius: 8,
          border: "none",
          background: c.teal,
          color: "#fff",
          fontSize: 11,
          fontWeight: 700,
          cursor: "pointer",
          marginBottom: 6,
        }}
      >
        ✨ امروز انجام دادم
      </button>

      <button
        onClick={doMissedDay}
        disabled={fiberCount === 0}
        style={{
          width: "100%",
          padding: "7px 0",
          borderRadius: 8,
          border: `1px solid ${c.border}`,
          background: "transparent",
          color: fiberCount === 0 ? c.border : c.inkSoft,
          fontSize: 11,
          fontWeight: 700,
          cursor: fiberCount === 0 ? "default" : "pointer",
          marginBottom: 6,
        }}
      >
        یک روز گذشت، انجام ندادم
      </button>

      {(fiberCount > 0 || habitFormed) && (
        <button
          onClick={doToggleHabit}
          style={{
            width: "100%",
            padding: "7px 0",
            borderRadius: 8,
            border: `1px solid ${habitFormed ? c.border : "#3F9B72"}`,
            background: habitFormed ? c.soft : "transparent",
            color: habitFormed ? c.inkSoft : "#2E7D5B",
            fontSize: 11,
            fontWeight: 700,
            cursor: "pointer",
            marginBottom: 6,
          }}
        >
          {habitFormed ? "↩️ هنوز کافی نیست، ادامه بده" : "✅ همینه، رفت تو حافظه‌ی دائمیم"}
        </button>
      )}

      <button
        onClick={() => setShowCalendar((v) => !v)}
        style={{
          width: "100%",
          padding: "3px 0",
          background: "transparent",
          border: "none",
          color: c.inkSoft,
          fontSize: 10,
          cursor: "pointer",
          textDecoration: "underline",
        }}
      >
        {showCalendar ? "بستنِ تقویم" : "نمایشِ تقویمِ این مسیر"}
      </button>
      {showCalendar && <NeuralCalendar id={id} events={calendarEvents} c={c} />}
    </div>
  );
}

/** دکمه‌ی کوچیکِ 🧬 که کنارِ هر بلندگو/آیتم می‌شینه؛ با تپ‌کردن، کارتِ
 *  مسیر عصبیِ همون آیتم به‌صورتِ popover باز می‌شه — پیش‌فرض چیزی نشون
 *  داده نمی‌شه تا هیچ‌جا شلوغ نشه.
 */
export function NeuralPathButton({ id, label, colors: cOverride }) {
  const [open, setOpen] = useState(false);
  const c = cOverride || DEFAULT_C;
  const safeLabel = label || "مورد";

  // جابجاییِ کارت با انگشت/موس — موقعیتِ کارت به‌صورتِ یه آفستِ نسبیِ
  // {x,y} از مرکزِ صفحه نگه داشته می‌شه. از Pointer Events (نه Touch/Mouse
  // جدا) استفاده شده چون هم لمسِ گوشی، هم موسِ دسکتاپ رو با یه کد پوشش
  // می‌ده؛ setPointerCapture هم باعث می‌شه حتی اگه انگشت سریع حرکت کنه و
  // از رویِ دستگیره بیرون بره، درگ قطع نشه.
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const dragRef = useRef({ dragging: false, startX: 0, startY: 0, baseX: 0, baseY: 0 });

  const onDragPointerDown = (e) => {
    e.stopPropagation();
    dragRef.current = { dragging: true, startX: e.clientX, startY: e.clientY, baseX: pos.x, baseY: pos.y };
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {}
  };
  const onDragPointerMove = (e) => {
    if (!dragRef.current.dragging) return;
    e.stopPropagation();
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    setPos({ x: dragRef.current.baseX + dx, y: dragRef.current.baseY + dy });
  };
  const onDragPointerUp = (e) => {
    dragRef.current.dragging = false;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {}
  };
  const dragHandleProps = {
    onPointerDown: onDragPointerDown,
    onPointerMove: onDragPointerMove,
    onPointerUp: onDragPointerUp,
    onPointerCancel: onDragPointerUp,
  };

  if (!id) return null;

  return (
    <span style={{ display: "inline-flex", flexShrink: 0 }}>
      <button
        onClick={(e) => {
          e.stopPropagation();
          // هر بار که کارت از نو باز می‌شه، دوباره از وسطِ صفحه شروع کنه —
          // نه از جایی که دفعه‌ی قبل کاربر جابجاش کرده بود.
          setPos({ x: 0, y: 0 });
          setOpen(true);
        }}
        title="مسیر عصبی"
        aria-label="مسیر عصبی"
        style={{
          width: 16,
          height: 16,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          borderRadius: "50%",
          border: "none",
          background: "transparent",
          cursor: "pointer",
          fontSize: 11,
          lineHeight: 1,
          opacity: 0.6,
          flexShrink: 0,
          padding: 0,
        }}
      >
        🧬
      </button>
      {open &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            onClick={() => setOpen(false)}
            style={{
              position: "fixed",
              inset: 0,
              // 🩹 طبقِ درخواستِ کاربر: این پاپ‌آور دیگه پشتِ خودش رو
              // کم‌رنگ/تیره نمی‌کنه — پس‌زمینه کاملاً شفافه (صفحه‌ی اصلی
              // ۱۰۰٪ واضح می‌مونه)؛ این لایه فقط برایِ گرفتنِ کلیکِ «بیرونِ
              // کارت = بستن» نگه داشته شده.
              background: "transparent",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 99999,
              padding: 16,
            }}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              style={{ transform: `translate(${pos.x}px, ${pos.y}px)` }}
            >
              <NeuralPathCard id={id} label={safeLabel} c={c} onClose={() => setOpen(false)} dragHandleProps={dragHandleProps} />
            </div>
          </div>,
          document.body
        )}
    </span>
  );
}
